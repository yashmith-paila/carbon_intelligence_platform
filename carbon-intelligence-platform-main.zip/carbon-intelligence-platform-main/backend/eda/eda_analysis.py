import pandas as pd
import numpy as np

def generate_eda_stats(csv_path: str):
    """
    Reads the dataset and generates EDA statistics.
    Returns a dictionary of insights.
    """
    try:
        df = pd.read_csv(csv_path)
        
        # Determine numeric columns for correlations
        numeric_df = df.select_dtypes(include=[np.number])
        
        # Core Statistics
        stats = {
            "mean_carbon_emission": round(df["Carbon_Emission_tCO2e_TARGET"].mean(), 2) if "Carbon_Emission_tCO2e_TARGET" in df else 0,
            "median_carbon_emission": round(df["Carbon_Emission_tCO2e_TARGET"].median(), 2) if "Carbon_Emission_tCO2e_TARGET" in df else 0,
            "std_carbon_emission": round(df["Carbon_Emission_tCO2e_TARGET"].std(), 2) if "Carbon_Emission_tCO2e_TARGET" in df else 0,
            "min_carbon_emission": round(df["Carbon_Emission_tCO2e_TARGET"].min(), 2) if "Carbon_Emission_tCO2e_TARGET" in df else 0,
            "max_carbon_emission": round(df["Carbon_Emission_tCO2e_TARGET"].max(), 2) if "Carbon_Emission_tCO2e_TARGET" in df else 0,
        }
        
        # Missing values
        missing_values = df.isnull().sum().to_dict()
        
        # Correlations (only if target exists)
        correlations = {}
        if "Carbon_Emission_tCO2e_TARGET" in numeric_df:
            corr_matrix = numeric_df.corr()
            correlations = corr_matrix["Carbon_Emission_tCO2e_TARGET"].drop("Carbon_Emission_tCO2e_TARGET").to_dict()
            # Round for output
            correlations = {k: round(v, 2) if not pd.isna(v) else 0.0 for k, v in correlations.items()}
            
        return {
            "status": "success",
            "statistics": stats,
            "missing_values": missing_values,
            "correlations": correlations,
            "row_count": len(df),
            "feature_count": len(df.columns)
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}
