import pandas as pd
import numpy as np

class ForecastModel:
    def __init__(self, model_type="lstm_mock"):
        self.model_type = model_type
        
    def train(self, df: pd.DataFrame, time_col: str, target_col: str):
        """
        Trains a time-series model. For this implementation, we simulate an LSTM or ARIMA.
        """
        return {"status": "trained mock model", "time_steps": len(df)}
        
    def forecast(self, steps=12, last_value=1000):
        """
        Forecasts future emissions for the next `steps` months.
        Using a mock polynomial trend matching standard EDA expectations.
        """
        predictions = []
        current = last_value
        for i in range(steps):
            # simulate a downward trend with slight noise
            noise = np.random.normal(0, 10)
            trend = -5.0 # downward trend per month
            current = current + trend + noise
            predictions.append(round(current, 2))
            
        return predictions
