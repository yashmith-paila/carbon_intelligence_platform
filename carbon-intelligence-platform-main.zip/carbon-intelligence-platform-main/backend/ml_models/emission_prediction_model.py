import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
import xgboost as xgb
import numpy as np
import joblib

class EmissionPredictor:
    def __init__(self, model_type="random_forest"):
        self.model_type = model_type
        self.model = None
        self.features = []
        
    def train(self, df: pd.DataFrame, target_col="Carbon_Emission_tCO2e_TARGET"):
        """
        Trains the selected model on the dataframe using a preprocessing pipeline.
        """
        if target_col not in df.columns:
            raise ValueError(f"Target column '{target_col}' not found.")
            
        X = df.drop(columns=[target_col])
        y = df[target_col]
        
        self.features = list(X.columns)
        
        # Identify column types
        numeric_features = X.select_dtypes(include=[np.number]).columns.tolist()
        categorical_features = X.select_dtypes(exclude=[np.number]).columns.tolist()
        
        # Create transformers
        numeric_transformer = Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ])
        
        categorical_transformer = Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
            ('onehot', OneHotEncoder(handle_unknown='ignore'))
        ])
        
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', numeric_transformer, numeric_features),
                ('cat', categorical_transformer, categorical_features)
            ])
            
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        if self.model_type == "random_forest":
            regressor = RandomForestRegressor(n_estimators=100, random_state=42)
        elif self.model_type == "xgboost":
            regressor = xgb.XGBRegressor(objective='reg:squarederror', n_estimators=100)
            
        self.model = Pipeline(steps=[('preprocessor', preprocessor),
                                     ('regressor', regressor)])
                                     
        self.model.fit(X_train, y_train)
        
        # Evaluation
        predictions = self.model.predict(X_test)
        metrics = {
            "MAE": round(float(mean_absolute_error(y_test, predictions)), 2),
            "RMSE": round(float(np.sqrt(mean_squared_error(y_test, predictions))), 2),
            "R2_Score": round(float(r2_score(y_test, predictions)), 2)
        }
        
        return metrics
        
    def predict(self, input_data: dict):
        """
        Predict based on trained model pipeline.
        """
        if not self.model:
            raise Exception("Model is not trained yet.")
            
        df_input = pd.DataFrame([input_data])
        # Align features
        for f in self.features:
            if f not in df_input.columns:
                df_input[f] = np.nan
                
        df_input = df_input[self.features]
        pred = self.model.predict(df_input)
        return float(pred[0])
    
    def save_model(self, filepath: str):
        joblib.dump({"model": self.model, "features": self.features}, filepath)
        
    def load_model(self, filepath: str):
        data = joblib.load(filepath)
        self.model = data["model"]
        self.features = data["features"]
