from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from utils.auth_deps import get_current_user, require_role
from database.mongodb import get_db
import uuid
import os
import joblib
import pandas as pd
from datetime import datetime
from services.recommendation_engine import generate_data_driven_recommendations

router = APIRouter()

# Load Model (Reusing logic from analytics_routes)
model_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "ml_models", "saved_models", "xgb_model.joblib"))
model_loaded = False
predictor = None

try:
    if os.path.exists(model_path):
        model_data = joblib.load(model_path)
        predictor = model_data["model"]
        model_loaded = True
except Exception as e:
    print(f"Warning: Simulation model load failed: {e}")

class SimulationRequest(BaseModel):
    industry: str
    production_efficiency_improvement: float  # %, eg. 10.0
    renewable_energy_share: float             # %, eg. 15.0
    reduce_transport_distance: float          # %, eg. 5.0

@router.post("/run")
async def run_simulation(request: SimulationRequest, current_user: dict = Depends(require_role(["Admin", "Manager", "Analyst"]))):
    db = get_db()
    
    # 1. Get Baseline (Last prediction or average emissions)
    last_record = await db["emission_records"].find_one(
        {"organization_id": current_user["organization_id"]},
        sort=[("created_at", -1)]
    )
    
    # Mock some baseline values if none exist, and assume some standard features
    baseline_energy = last_record.get("energy_consumption", 5000) if last_record else 5000
    baseline_renewable = last_record.get("renewable_share", 0.1) if last_record else 0.1
    baseline_output = last_record.get("production_output", 10000) if last_record else 10000
    baseline_emissions = last_record.get("carbon_emissions", 1000) if last_record else 1000

    # 2. Calculate Scenario Parameters
    # IMPROVEMENT: If renewable energy share increases, it's a direct fraction
    scenario_renewable = min(1.0, baseline_renewable + (request.renewable_energy_share / 100))
    # Production efficiency improvement reduces consumption per unit
    scenario_energy = baseline_energy * (1 - (request.production_efficiency_improvement / 100))
    
    # 3. Use ML Model for Prediction if available
    if model_loaded:
        try:
            # Construct feature vector matching model training
            # Features: Energy_Consumption, Renewable_Energy_Share, Production_Output, Supply_Chain_Transport_Distance, Raw_Material_Usage, Industry
            input_data = pd.DataFrame([{
                "Energy_Consumption": scenario_energy,
                "Renewable_Energy_Share": scenario_renewable,
                "Production_Output": baseline_output,
                "Supply_Chain_Transport_Distance": 100 * (1 - (request.reduce_transport_distance / 100)),
                "Raw_Material_Usage": 500, # default or organization profile
                "Industry": request.industry
            }])
            
            scenario_emissions = float(predictor.predict(input_data)[0])
        except Exception:
            # Fallback to math if features don't match exactly
            reduction = (request.renewable_energy_share * 0.45) + (request.production_efficiency_improvement * 0.4)
            scenario_emissions = baseline_emissions * (1 - (reduction / 100))
    else:
        # Heuristic Fallback
        reduction = (request.renewable_energy_share * 0.45) + (request.production_efficiency_improvement * 0.4)
        scenario_emissions = baseline_emissions * (1 - (reduction / 100))

    emission_change_percent = ((scenario_emissions - baseline_emissions) / baseline_emissions) * 100
    
    # 4. Get AI Suggestions for this specific scenario
    # Pass a simplified "mock record" to the engine to simulate the scenario
    scenario_record = {
        "renewable_share": scenario_renewable * 100,
        "energy_consumption": scenario_energy,
        "production_output": baseline_output,
        "carbon_emissions": scenario_emissions,
        "transport_distance": 100 * (1 - (request.reduce_transport_distance / 100))
    }
    ai_feedback = generate_data_driven_recommendations([scenario_record], industry=request.industry)
    
    results = {
        "baseline_emissions": round(float(baseline_emissions), 2),
        "scenario_emissions": round(float(scenario_emissions), 2),
        "emission_change": f"{emission_change_percent:+.1f}%",
        "cost_impact": f"${(request.renewable_energy_share * 1500 + request.production_efficiency_improvement * 2000):,.0f}",
        "roi": f"{max(0.5, 5.0 - (abs(emission_change_percent) * 0.1)):.1f} Years",
        "ai_suggestions": ai_feedback[:2] # Top 2 relevant ones
    }
    
    # Save simulation history
    sim_doc = {
        "_id": str(uuid.uuid4()),
        "organization_id": current_user["organization_id"],
        "scenario_name": f"Dynamic Simulation: {request.industry}",
        "parameters": request.dict(),
        "results": results,
        "created_at": datetime.utcnow()
    }
    await db["simulations"].insert_one(sim_doc)
    
    return {
        "status": "success",
        "results": results
    }
