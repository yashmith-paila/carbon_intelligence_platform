from fastapi import APIRouter, HTTPException, Depends, status
from pydantic import BaseModel, EmailStr
from database.mongodb import get_db
from database.models import UserCreate, UserInDB, OrganizationSchema, Token
from utils.password_hash import hash_password, verify_password
from utils.jwt_handler import sign_jwt
import uuid
from datetime import datetime

router = APIRouter()

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class ForgotPasswordRequest(BaseModel):
    email: EmailStr

class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str

@router.post("/signup", response_model=Token, status_code=status.HTTP_201_CREATED)
async def signup(user: UserCreate):
    db = get_db()
    
    # Check if user already exists
    existing_user = await db["users"].find_one({"email": user.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")

    # Create Organization first
    org_doc = OrganizationSchema(
        organization_name=user.organization_name,
        industry=user.industry,
        country=user.country
    ).dict(by_alias=True, exclude_none=True)
    org_doc["_id"] = str(uuid.uuid4())
    
    await db["organizations"].insert_one(org_doc)
    
    # Create User
    user_doc = UserInDB(
        _id=str(uuid.uuid4()),
        name=user.name,
        email=user.email,
        role=user.role,
        password_hash=hash_password(user.password),
        organization_id=org_doc["_id"],
        created_at=datetime.utcnow()
    ).dict(by_alias=True)
    
    await db["users"].insert_one(user_doc)
    
    # Generate JWT
    token = sign_jwt(user_id=user_doc["_id"], role=user_doc["role"])
    
    return {"access_token": token, "token_type": "bearer"}

@router.post("/login", response_model=Token)
async def login(credentials: LoginRequest):
    db = get_db()
    
    # Find user
    user_doc = await db["users"].find_one({"email": credentials.email})
    if not user_doc:
        raise HTTPException(status_code=401, detail="Invalid credentials")
        
    # Verify password
    if not verify_password(credentials.password, user_doc["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
        
    # Generate JWT
    token = sign_jwt(user_id=str(user_doc["_id"]), role=user_doc["role"])
    
    return {"access_token": token, "token_type": "bearer"}

@router.post("/forgot-password")
async def forgot_password(req: ForgotPasswordRequest):
    db = get_db()
    user = await db["users"].find_one({"email": req.email})
    if user:
        # In a real app, generate a reset token and send an email
        pass
    return {"message": "If that email exists, a reset link has been sent."}

@router.post("/reset-password")
async def reset_password(req: ResetPasswordRequest):
    # In a real app, verify the token
    # For this SaaS demo, we will pretend success
    return {"message": "Password has been successfully reset."}
