from fastapi import APIRouter, Depends
from utils.auth_deps import get_current_user
from database.mongodb import get_db


router = APIRouter()

@router.get("/")
async def get_ai_recommendations(current_user: dict = Depends(get_current_user)):
    db = get_db()
    
    # 1. Fetch emission records
    cursor = db["emission_records"].find({"organization_id": current_user["organization_id"]})
    records = await cursor.to_list(length=1000)
    
    # 2. Fetch latest prediction
    latest_prediction = await db["predictions"].find_one(
        {"organization_id": current_user["organization_id"]},
        sort=[("created_at", -1)]
    )
    
    total_emissions = sum(r.get("carbon_emissions", 0) for r in records)
    industry = current_user.get("industry", "General")
    
    # 3. Generate data-driven recommendations
    from services.recommendation_engine import generate_data_driven_recommendations
    recommendations = generate_data_driven_recommendations(records, latest_prediction, industry)
    
    # Add IDs to recommendations for frontend mapping
    for idx, rec in enumerate(recommendations):
        rec["id"] = idx + 1
            
    return {
        "status": "success",
        "industry": industry,
        "total_emissions": total_emissions,
        "recommendations": recommendations
    }
