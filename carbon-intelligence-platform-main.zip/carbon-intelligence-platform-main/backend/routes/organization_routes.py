from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from database.mongodb import get_db
from database.models import OrganizationSchema
from utils.auth_deps import get_current_user
import pandas as pd
import io
import uuid
from datetime import datetime

router = APIRouter()

@router.get("/")
async def get_organization(current_user: dict = Depends(get_current_user)):
    db = get_db()
    org = await db["organizations"].find_one({"_id": current_user["organization_id"]})
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    return {"status": "success", "organization": org}

@router.post("/upload-dataset")
async def upload_organization_dataset(
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
):
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files are supported")
        
    try:
        contents = await file.read()
        df = pd.read_csv(io.BytesIO(contents))
        
        # Basic validation of required columns for our ML/Analytics
        required_cols = ['energy_consumption', 'renewable_share', 'production_output', 'carbon_emissions']
        missing = [col for col in required_cols if col not in df.columns]
        
        if missing:
            raise HTTPException(status_code=400, detail=f"Missing columns: {', '.join(missing)}")
            
        db = get_db()
        
        # Convert dataframe to list of dicts for MongoDB
        records = []
        for _, row in df.iterrows():
            record = {
                "_id": str(uuid.uuid4()),
                "organization_id": current_user["organization_id"],
                "energy_consumption": float(row['energy_consumption']),
                "renewable_share": float(row['renewable_share']),
                "production_output": float(row['production_output']),
                "transport_distance": float(row.get('transport_distance', 0)),
                "transport_mode": str(row.get('transport_mode', 'Unknown')),
                "carbon_emissions": float(row['carbon_emissions']),
                "created_at": datetime.utcnow()
            }
            records.append(record)
            
        if records:
            await db["emission_records"].insert_many(records)
            
        # Update organization status
        await db["organizations"].update_one(
            {"_id": current_user["organization_id"]},
            {"$set": {"has_onboarded": True}}
        )
        
        return {
            "status": "success", 
            "message": f"Successfully processed {len(records)} records",
            "count": len(records)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing CSV: {str(e)}")

@router.post("/manual-onboarding")
async def manual_onboarding(
    payload: dict,
    current_user: dict = Depends(get_current_user)
):
    db = get_db()
    
    # Save manual scope data
    update_data = {
        "scope1Custom": float(payload.get("scope1", 0)),
        "scope2Custom": float(payload.get("scope2", 0)),
        "scope3Custom": float(payload.get("scope3", 0)),
        "has_onboarded": True
    }
    
    await db["organizations"].update_one(
        {"_id": current_user["organization_id"]},
        {"$set": update_data}
    )
    
    # Also create a summary record in emissions for analytics to pick up
    summary_record = {
        "_id": str(uuid.uuid4()),
        "organization_id": current_user["organization_id"],
        "energy_consumption": 0, # Manual sum usually doesn't provide this detail
        "renewable_share": 0,
        "production_output": 0,
        "transport_distance": 0,
        "transport_mode": "Manual Entry",
        "carbon_emissions": float(update_data["scope1Custom"]) + float(update_data["scope2Custom"]) + float(update_data["scope3Custom"]),
        "created_at": datetime.utcnow()
    }
    await db["emission_records"].insert_one(summary_record)
    
    return {"status": "success", "message": "Onboarding complete"}

@router.put("/update")
async def update_organization(org_data: OrganizationSchema, current_user: dict = Depends(get_current_user)):
    # Restrict to Managers or Admins ideally
    if current_user["role"] not in ["Admin", "Manager"]:
         raise HTTPException(status_code=403, detail="Not enough privileges to update organization")
         
    db = get_db()
    update_data = org_data.dict(exclude_unset=True)
    # Don't update the ID
    update_data.pop("id", None) 
    update_data.pop("_id", None)
    
    result = await db["organizations"].update_one(
        {"_id": current_user["organization_id"]},
        {"$set": update_data}
    )
    
    if result.modified_count == 0:
        return {"status": "info", "message": "No changes made or org not found"}
        
    return {"status": "success", "message": "Organization updated successfully"}
