from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from utils.auth_deps import require_role
from database.mongodb import get_db
import uuid
import os
from datetime import datetime
import pandas as pd
from fpdf import FPDF
from fastapi.responses import FileResponse

router = APIRouter()

class ReportRequest(BaseModel):
    report_type: str # "EDA", "Prediction", "Simulation"

REPORTS_DIR = os.path.join(os.path.dirname(__file__), "..", "reports_generated")
os.makedirs(REPORTS_DIR, exist_ok=True)

@router.post("/generate")
async def generate_report(req: ReportRequest, current_user: dict = Depends(require_role(["Admin", "Manager"]))):
    db = get_db()
    report_id = str(uuid.uuid4())
    date_str = datetime.utcnow().strftime('%Y-%m-%d')
    file_base = f"{req.report_type}_Report_{date_str}_{report_id[:8]}"
    
    if req.report_type == "Simulation":
        cursor = db["simulations"].find({"organization_id": current_user["organization_id"]}).limit(10)
        docs = await cursor.to_list(length=10)
        # Create CSV
        csv_path = os.path.join(REPORTS_DIR, f"{file_base}.csv")
        df = pd.json_normalize(docs)
        df.to_csv(csv_path, index=False)
        
        # Create minimal PDF
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.cell(200, 10, txt=f"Sustainability Report: {req.report_type}", ln=True, align='C')
        pdf.cell(200, 10, txt=f"Generated: {date_str}", ln=True)
        pdf.cell(200, 10, txt="Recent Simulations:", ln=True)
        for d in docs:
            name = d.get('scenario_name', "N/A")
            pdf.cell(200, 10, txt=f"- {name}", ln=True)
            
        pdf_path = os.path.join(REPORTS_DIR, f"{file_base}.pdf")
        pdf.output(pdf_path)
        
    elif req.report_type == "Prediction":
        cursor = db["predictions"].find({"organization_id": current_user["organization_id"]}).limit(10)
        docs = await cursor.to_list(length=10)
        csv_path = os.path.join(REPORTS_DIR, f"{file_base}.csv")
        df = pd.json_normalize(docs)
        df.to_csv(csv_path, index=False)
        
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.cell(200, 10, txt=f"Carbon Footprint Summary: {req.report_type}", ln=True, align='C')
        for d in docs:
            emission = d.get('predicted_emission', 0)
            model = d.get('model_used', 'N/A')
            pdf.cell(200, 10, txt=f"- Model: {model} -> Predicted: {emission} tCO2e", ln=True)
            
        pdf_path = os.path.join(REPORTS_DIR, f"{file_base}.pdf")
        pdf.output(pdf_path)
    else:
        # Generic EDA or other
        csv_path = os.path.join(REPORTS_DIR, f"{file_base}.csv")
        pd.DataFrame([{"info": "EDA Report is statically generated in /eda endpoint."}]).to_csv(csv_path)
        pdf_path = os.path.join(REPORTS_DIR, f"{file_base}.pdf")
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.cell(200, 10, txt="EDA summary available on dashboard.", ln=True)
        pdf.output(pdf_path)

    from database.models import ReportSchema
    
    report_doc = ReportSchema(
        _id=report_id,
        organization_id=current_user["organization_id"],
        report_name=f"{req.report_type} Report - {date_str}",
        report_type=req.report_type,
        file_path=pdf_path,
        created_at=datetime.utcnow()
    ).dict(by_alias=True)
    
    await db["reports"].insert_one(report_doc)
    
    return {
        "status": "success", 
        "message": "Report generated",
        "report_id": report_id,
        "csv_path": csv_path,
        "pdf_path": pdf_path
    }

@router.get("/download/{report_id}")
async def download_report(report_id: str, format: str = "pdf", current_user: dict = Depends(require_role(["Admin", "Manager", "Analyst"]))):
    db = get_db()
    report = await db["reports"].find_one({"_id": report_id, "organization_id": current_user["organization_id"]})
    
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
        
    base_file = report["file_path"].rsplit('.', 1)[0]
    target_file = f"{base_file}.{format}"
    
    if not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail=f"File {target_file} not found.")
        
    return FileResponse(path=target_file, media_type='application/pdf' if format == 'pdf' else 'text/csv', filename=os.path.basename(target_file))
