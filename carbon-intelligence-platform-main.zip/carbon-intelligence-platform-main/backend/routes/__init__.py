# Initialize routes package
from .auth_routes import router as auth_router
from .emissions_routes import router as emissions_router
from .analytics_routes import router as analytics_router
from .simulation_routes import router as simulation_router
from .user_routes import router as user_router
from .organization_routes import router as organization_router
from .report_routes import router as report_router
from .recommendation_routes import router as recommendation_router
