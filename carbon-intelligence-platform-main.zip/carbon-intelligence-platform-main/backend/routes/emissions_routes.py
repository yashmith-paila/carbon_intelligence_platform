from fastapi import APIRouter, HTTPException, Depends
from database.mongodb import get_db
from utils.auth_deps import get_current_user, require_role
from database.models import EmissionRecordSchema
import uuid
from datetime import datetime

router = APIRouter()

@router.post("/add")
async def add_emission_record(
    record: EmissionRecordSchema,
    current_user: dict = Depends(require_role(["Admin", "Manager"]))
):
    try:
        db = get_db()
        record_doc = record.dict(by_alias=True)
        if not record_doc.get("_id"):
            record_doc["_id"] = str(uuid.uuid4())
        record_doc["organization_id"] = current_user["organization_id"]
        record_doc["created_at"] = datetime.utcnow()
        
        await db["emission_records"].insert_one(record_doc)
        
        return {
            "status": "success", 
            "message": "Emission record added successfully",
            "record_id": record_doc["_id"]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/list")
async def list_emission_records(current_user: dict = Depends(get_current_user)):
    db = get_db()
    cursor = db["emission_records"].find({"organization_id": current_user["organization_id"]})
    records = await cursor.to_list(length=100)
    return {"status": "success", "emission_records": records}
