from fastapi import APIRouter, Depends
from utils.auth_deps import get_current_user

router = APIRouter()

@router.get("/profile")
async def get_profile(current_user: dict = Depends(get_current_user)):
    user_data = current_user.copy()
    user_data.pop("password_hash", None) # Do not send hash to frontend
    return {"status": "success", "user": user_data}

@router.put("/update")
async def update_profile(current_user: dict = Depends(get_current_user)):
    # Simple mock response
    return {"status": "success", "message": "Profile updated successfully"}
