from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from eda.eda_analysis import generate_eda_stats
import os
import joblib
from utils.auth_deps import get_current_user, require_role
from database.mongodb import get_db
import uuid
from datetime import datetime

router = APIRouter()

# Load Model
model_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "ml_models", "saved_models", "xgb_model.joblib"))
try:
    model_data = joblib.load(model_path)
    predictor = model_data["model"]
    features_list = model_data["features"]
    model_loaded = True
except Exception as e:
    model_loaded = False
    print(f"Warning: Could not load ML model from {model_path}. Error: {e}")

class PredictionInput(BaseModel):
    Energy_Consumption: float
    Renewable_Energy_Share: float
    Production_Output: float
    Supply_Chain_Transport_Distance: float
    Transport_Mode: str
    Raw_Material_Usage: float
    Industry: str

@router.get("/dashboard-stats")
async def get_dashboard_stats(current_user: dict = Depends(require_role(["Admin", "Manager", "Analyst"]))):
    db = get_db()
    
    # Aggregate total emissions from records
    pipeline = [
        {"$match": {"organization_id": current_user["organization_id"]}},
        {"$group": {"_id": None, "total": {"$sum": "$carbon_emissions"}, "count": {"$sum": 1}}}
    ]
    cursor = db["emission_records"].aggregate(pipeline)
    agg_result = await cursor.to_list(length=1)
    
    total = agg_result[0]["total"] if agg_result else 0
    count = agg_result[0]["count"] if agg_result else 0
    
    # Get last prediction
    last_pred = await db["predictions"].find_one(
        {"organization_id": current_user["organization_id"]},
        sort=[("created_at", -1)]
    )
    predicted = last_pred["predicted_emission"] if last_pred else 0
    
    return {
        "total_emissions": round(total, 2),
        "emission_trend": -5.2, # Mock trend for now
        "esg_score": 85 if count > 0 else 0,
        "predicted_emissions": round(predicted, 2),
        "sustainability_progress": min(100, count * 10) if count < 10 else 95,
        "record_count": count
    }

@router.get("/eda")
async def get_eda_insights(current_user: dict = Depends(require_role(["Admin", "Manager", "Analyst"]))):
    # Retrieve pre-generated EDA text or trigger function
    # dataset_path = "E:/coding world/web dev/hack/carbon_emission_dataset_with_Industry.csv"
    # Use relative path from the backend directory
    # Try multiple possible locations for the dataset
    possible_paths = [
        os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "carbon_emission_dataset_with_Industry.csv")),
        os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "eda", "carbon_emission_dataset_with_Industry.csv")),
        "E:/coding world/web dev/hack/carbon_emission_dataset_with_Industry.csv"
    ]
    
    dataset_path = None
    for path in possible_paths:
        if os.path.exists(path):
            dataset_path = path
            break
            
    if dataset_path:
        stats = generate_eda_stats(dataset_path)
        return stats
    else:
        return {"status": "error", "message": "Dataset not found in expected locations."}

@router.post("/predict")
async def predict_emissions(data: PredictionInput, current_user: dict = Depends(require_role(["Admin", "Manager", "Analyst"]))):
    if not model_loaded:
        raise HTTPException(status_code=500, detail="ML Model is not loaded. Please train the model first.")
        
    try:
        import pandas as pd
        input_dict = data.dict()
        df_input = pd.DataFrame([input_dict])
        
        # Predict using the joblib loaded pipeline
        prediction = float(predictor.predict(df_input)[0])
        
        db = get_db()
        from database.models import EmissionPredictionSchema
        
        pred_record = EmissionPredictionSchema(
            _id=str(uuid.uuid4()),
            organization_id=current_user["organization_id"],
            energy_consumption=data.Energy_Consumption,
            renewable_share=data.Renewable_Energy_Share,
            production_output=data.Production_Output,
            predicted_emission=prediction,
            model_used="XGBoost",
            created_at=datetime.utcnow()
        ).dict(by_alias=True)
        
        await db["predictions"].insert_one(pred_record)
        
        return {
            "status": "success",
            "predicted_emission_tCO2e": prediction,
            "prediction_id": pred_record["_id"]
        }
    except Exception as e:
        import traceback
        import sys
        traceback.print_exc(file=sys.stdout)
        raise HTTPException(status_code=500, detail=str(e))

