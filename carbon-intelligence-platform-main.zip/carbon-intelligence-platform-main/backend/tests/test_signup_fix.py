
import requests
import uuid

def test_signup():
    url = "http://localhost:8000/api/auth/signup"
    unique_email = f"test_{uuid.uuid4().hex[:8]}@example.com"
    payload = {
        "name": "Test User",
        "email": unique_email,
        "password": "testpassword123",
        "organization_name": "Test Org",
        "industry": "Tech",
        "country": "Test Country"
    }
    
    try:
        print(f"Testing signup with email: {unique_email}")
        response = requests.post(url, json=payload)
        print(f"Status Code: {response.status_code}")
        print(f"Response Body: {response.text}")
        
        if response.status_code == 201:
            print("Signup successful!")
        else:
            print("Signup failed.")
            
    except Exception as e:
        print(f"Error during request: {e}")

if __name__ == "__main__":
    test_signup()
