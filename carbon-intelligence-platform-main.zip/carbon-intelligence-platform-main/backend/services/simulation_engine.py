def run_scenario_simulation(
    current_emissions: float, 
    current_cost: float, 
    production_increase_pct: float, 
    renewable_adoption_pct: float
):
    """
    Simulates the impact of business decisions on carbon emissions and cost.
    """
    new_production_factor = 1.0 + (production_increase_pct / 100.0)
    
    # Simple linear relationship for simulation
    projected_emissions_before_renewables = current_emissions * new_production_factor
    projected_cost = current_cost * new_production_factor
    
    # Renewable adoption reduces emissions by the adoption percentage relative to the total envelope
    reduction_from_renewables = projected_emissions_before_renewables * (renewable_adoption_pct / 100.0)
    final_emissions = projected_emissions_before_renewables - reduction_from_renewables
    
    emission_change = final_emissions - current_emissions
    emission_change_pct = (emission_change / current_emissions) * 100.0
    
    # Renewable cost (mock assumption: $1,000 per ton of reduction capacity)
    implementation_cost = reduction_from_renewables * 1000 
    
    # ROI based on carbon tax savings (mock $50 per ton)
    carbon_tax_savings = reduction_from_renewables * 50
    roi_years = implementation_cost / carbon_tax_savings if carbon_tax_savings > 0 else 0
    
    return {
        "final_emissions": round(final_emissions, 2),
        "emission_change_pct": round(emission_change_pct, 2),
        "implementation_cost": round(implementation_cost, 2),
        "roi_years": round(roi_years, 1),
        "esg_score_change": round(renewable_adoption_pct * 0.5, 1) # simple mapping
    }
