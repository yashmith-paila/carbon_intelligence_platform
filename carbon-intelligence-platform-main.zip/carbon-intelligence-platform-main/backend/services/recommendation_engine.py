import os
from dotenv import load_dotenv

load_dotenv()



def generate_data_driven_recommendations(records, latest_prediction=None, industry="General"):
    """
    Generates actionable carbon reduction strategies by analyzing real organization data.
    """
    recommendations = []
    
    if not records:
        return get_mock_recommendations(industry)

    # 1. Analyze Renewable Energy Share
    avg_renewable = sum(r.get("renewable_share", 0) for r in records) / len(records)
    if avg_renewable < 30:
        recommendations.append({
            "strategy": "Expand Renewable Energy Infrastructure",
            "estimated_reduction": "25%",
            "estimated_cost": "$150,000",
            "roi": "4 Years",
            "priority": "High"
        })
    elif avg_renewable < 70:
        recommendations.append({
            "strategy": "Optimize Solar/Wind Integration",
            "estimated_reduction": "10%",
            "estimated_cost": "$40,000",
            "roi": "2 Years",
            "priority": "Medium"
        })

    # 2. Analyze Operational Efficiency (Energy per Production)
    total_energy = sum(r.get("energy_consumption", 0) for r in records)
    total_prod = sum(r.get("production_output", 0) for r in records)
    
    if total_prod > 0:
        energy_intensity = total_energy / total_prod
        if energy_intensity > 1.5: # Threshold example
            recommendations.append({
                "strategy": "Hardware Efficiency Retrofit",
                "estimated_reduction": "12%",
                "estimated_cost": "$75,000",
                "roi": "1.5 Years",
                "priority": "High"
            })

    # 3. Analyze Supply Chain (Transport Distance)
    avg_dist = sum(r.get("transport_distance", 0) for r in records) / len(records)
    if avg_dist > 500:
        recommendations.append({
            "strategy": "Localized Sourcing & Logistics Optimization",
            "estimated_reduction": "18%",
            "estimated_cost": "$30,000",
            "roi": "1 Year",
            "priority": "Medium"
        })

    # 4. Analyze Prediction Trends
    if latest_prediction:
        predicted = latest_prediction.get("predicted_emission", 0)
        avg_emissions = sum(r.get("carbon_emissions", 0) for r in records) / len(records)
        
        if predicted > avg_emissions * 1.1: # 10% increase predicted
            recommendations.append({
                "strategy": "AI-Driven Peak Load Balancing",
                "estimated_reduction": "15%",
                "estimated_cost": "$15,000",
                "roi": "0.5 Years",
                "priority": "High"
            })

    # Fallback/Safety: Ensure at least some recommendations
    if not recommendations:
        return get_mock_recommendations(industry)
        
    return recommendations[:4] # Return top 4

def get_mock_recommendations(industry: str):
    """
    Fallback mock recommendations for empty datasets.
    """
    return [
        {
            "strategy": f"Industry-Specific {industry} Efficiency Audit",
            "estimated_reduction": "5%",
            "estimated_cost": "$10,000",
            "roi": "1 Year",
            "priority": "Medium"
        },
        {
            "strategy": "LED Lighting Transition",
            "estimated_reduction": "2%",
            "estimated_cost": "$5,000",
            "roi": "0.5 Years",
            "priority": "Low"
        }
    ]
