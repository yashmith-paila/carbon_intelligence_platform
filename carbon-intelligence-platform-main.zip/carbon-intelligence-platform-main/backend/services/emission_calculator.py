def calculate_carbon_footprint(data: dict) -> float:
    """
    Calculates carbon emissions based on provided logical factors.
    """
    energy = data.get("energy_consumption", 0.0)
    renewable_share = data.get("renewable_share", 0.0)
    production = data.get("production_output", 0.0)
    distance = data.get("transport_distance", 0.0)
    
    # Simple standardized mock calculation logic
    # Energy to carbon (e.g., 0.4 kg CO2 per kWh, offset by renewable)
    energy_emission = energy * 0.4 * (1.0 - (renewable_share / 100.0))
    
    # Production baseline
    production_emission = production * 1.5
    
    # Transport (e.g., 0.15 kg CO2 per km)
    transport_emission = distance * 0.15
    
    total = energy_emission + production_emission + transport_emission
    return round(total, 2)
