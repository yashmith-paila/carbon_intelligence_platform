from pydantic import BaseModel, Field, EmailStr
from typing import Optional, List, Any
from datetime import datetime

class UserBase(BaseModel):
    name: str
    email: EmailStr
    role: str = "Manager" # Default role, can be Admin, Manager, Analyst

class UserCreate(UserBase):
    password: str
    organization_name: str
    industry: str
    country: str

class UserInDB(UserBase):
    id: str = Field(alias="_id")
    password_hash: str
    organization_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

class OrganizationSchema(BaseModel):
    id: Optional[str] = Field(alias="_id", default=None)
    organization_name: str
    industry: str
    country: str
    number_of_facilities: Optional[int] = 0
    energy_sources: Optional[List[str]] = []
    production_scale: Optional[str] = ""
    scope1Custom: Optional[float] = 0.0 # Standard name for direct emissions
    scope2Custom: Optional[float] = 0.0 # Standard name for indirect energy
    scope3Custom: Optional[float] = 0.0 # Standard name for supply chain
    has_onboarded: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)

class FacilitySchema(BaseModel):
    id: Optional[str] = Field(alias="_id", default=None)
    organization_id: str
    name: str
    location: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

class EmissionRecordSchema(BaseModel):
    id: Optional[str] = Field(alias="_id", default=None)
    organization_id: str
    facility_id: Optional[str] = None
    energy_consumption: float
    renewable_share: float
    production_output: float
    transport_distance: float
    transport_mode: str
    carbon_emissions: float
    created_at: datetime = Field(default_factory=datetime.utcnow)

class DatasetSchema(BaseModel):
    id: Optional[str] = Field(alias="_id", default=None)
    organization_id: str
    filename: str
    uploaded_by: str
    row_count: int = 0
    status: str = "Processed"
    created_at: datetime = Field(default_factory=datetime.utcnow)

class EmissionPredictionSchema(BaseModel):
    model_config = {'protected_namespaces': ()}
    id: Optional[str] = Field(alias="_id", default=None)
    organization_id: str
    energy_consumption: float
    renewable_share: float
    production_output: float
    predicted_emission: float
    model_used: str = "XGBoost"
    created_at: datetime = Field(default_factory=datetime.utcnow)

class SimulationSchema(BaseModel):
    id: Optional[str] = Field(alias="_id", default=None)
    organization_id: str
    scenario_name: str
    parameters: dict
    results: dict
    created_at: datetime = Field(default_factory=datetime.utcnow)

class ReportSchema(BaseModel):
    id: Optional[str] = Field(alias="_id", default=None)
    organization_id: str
    report_name: str
    report_type: str # "EDA", "Prediction", "Simulation" 
    file_path: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Token(BaseModel):
    access_token: str
    token_type: str

