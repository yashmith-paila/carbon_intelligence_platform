import React from 'react';

export default function Roadmap() {
  return (
    <div className="w-full">
      <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-teal-500 to-blue-600 mb-6">
        Sustainability Roadmap
      </h1>
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
        <div className="space-y-6">
          {[
            { year: 'Year 1', desc: 'Supply chain optimization' },
            { year: 'Year 2', desc: 'Renewable energy adoption' },
            { year: 'Year 3', desc: 'Process efficiency upgrades' }
          ].map((step, idx) => (
            <div key={idx} className="flex items-center gap-4">
              <div className="w-16 py-2 bg-blue-50 text-blue-700 rounded-lg text-center font-bold">{step.year}</div>
              <div className="flex-1 bg-gray-50 p-4 rounded-lg border border-gray-100">{step.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
