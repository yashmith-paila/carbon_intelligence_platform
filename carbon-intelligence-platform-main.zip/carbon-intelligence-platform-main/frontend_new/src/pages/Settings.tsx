import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';

export default function Settings() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<any>(null);
  const [org, setOrg] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');


  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        navigate('/signin');
        return;
      }

      // Fetch Profile
      const profileRes = await api.get('/users/profile');
      setProfile(profileRes.data.profile);
      
      // Fetch Organization
      const orgRes = await api.get('/organization');
      setOrg(orgRes.data.organization);
    } catch (err) {
      console.error("Failed to load settings data", err);
    } finally {
      setLoading(false);
    }
  };

  const handleOrgChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setOrg({ ...org, [e.target.name]: e.target.value });
  };

  const handleOrgSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage('');
    
    try {
      await api.put('/organization', org);
      setMessage('Organization settings updated successfully.');
    } catch (err: any) {
      setMessage(err.response?.data?.detail || 'Update failed');
    } finally {
      setSaving(false);
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    window.dispatchEvent(new Event('auth-change'));
    navigate('/signin');
  };

  if (loading) {
    return <div className="p-12 text-center text-gray-500 animate-pulse">Loading settings...</div>;
  }

  return (
    <div className="w-full max-w-5xl mx-auto pb-12">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-teal-500 to-blue-600">
          Settings & Profile
        </h1>
        <button 
          onClick={handleLogout}
          className="px-4 py-2 bg-red-50 text-red-600 hover:bg-red-100 font-medium rounded-xl transition-colors border border-red-100"
        >
          Sign Out
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* User Profile Info */}
        <div className="md:col-span-1 space-y-6">
           <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
             <div className="flex items-center space-x-4 mb-6">
               <div className="h-16 w-16 bg-gradient-to-br from-blue-100 to-teal-100 rounded-full flex items-center justify-center border-2 border-white shadow-sm">
                  <span className="text-2xl font-bold text-teal-600">{profile?.name?.charAt(0) || 'U'}</span>
               </div>
               <div>
                  <h2 className="text-lg font-bold text-gray-800">{profile?.name}</h2>
                  <p className="text-sm text-gray-500">{profile?.role}</p>
               </div>
             </div>
             
             <div className="pt-4 border-t border-gray-50 space-y-3">
                <div>
                   <p className="text-xs font-medium text-gray-400 uppercase">Email</p>
                   <p className="text-sm text-gray-800 mt-1">{profile?.email}</p>
                </div>
                <div>
                   <p className="text-xs font-medium text-gray-400 uppercase">Member Since</p>
                   <p className="text-sm text-gray-800 mt-1">{profile?.created_at ? new Date(profile.created_at).toLocaleDateString() : 'N/A'}</p>
                </div>
             </div>
           </div>
           
           <div className="bg-gradient-to-br from-slate-800 to-slate-900 p-6 rounded-2xl shadow-lg text-white">
              <h3 className="font-semibold mb-2 flex items-center">
                 <svg className="w-5 h-5 mr-2 text-yellow-400" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
                 Pro Plan Active
              </h3>
              <p className="text-sm text-slate-300 mb-4 opacity-80">Your organization has full access to AI recommendations and reports.</p>
              <button className="w-full py-2 bg-white/10 hover:bg-white/20 transition-colors rounded-lg text-sm font-medium">Manage Billing</button>
           </div>
        </div>
        
        {/* Organization Settings */}
        <div className="md:col-span-2 bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
           <h2 className="text-xl font-semibold mb-6 text-gray-800">Organization Settings</h2>
           
           {message && (
             <div className="mb-6 p-3 bg-green-50 text-green-700 border border-green-100 rounded-xl text-sm transition-all">
               {message}
             </div>
           )}
           
           {org && (
             <form onSubmit={handleOrgSubmit} className="space-y-5">
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Organization Name</label>
                    <input type="text" name="name" value={org.name || ''} onChange={handleOrgChange} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all outline-none bg-gray-50 focus:bg-white text-gray-900" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Industry</label>
                    <select name="industry" value={org.industry || ''} onChange={handleOrgChange} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all outline-none bg-gray-50 focus:bg-white text-gray-900">
                      <option value="Technology">Technology</option>
                      <option value="Manufacturing">Manufacturing</option>
                      <option value="Energy">Energy</option>
                      <option value="Transportation">Transportation</option>
                      <option value="Retail">Retail</option>
                      <option value="Agriculture">Agriculture</option>
                      <option value="Construction">Construction</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
                    <input type="text" name="country" value={org.country || ''} onChange={handleOrgChange} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all outline-none bg-gray-50 focus:bg-white text-gray-900" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Target Net Zero Year</label>
                    <input type="number" name="target_net_zero_year" value={org.target_net_zero_year || ''} onChange={handleOrgChange} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all outline-none bg-gray-50 focus:bg-white text-gray-900" placeholder="2030" />
                  </div>
                </div>
                
                <div className="pt-4 mt-2">
                   <button 
                     type="submit" 
                     disabled={saving}
                     className="bg-teal-600 hover:bg-teal-700 text-white font-medium py-2.5 px-6 rounded-xl transition-all disabled:opacity-50 flex items-center"
                   >
                      {saving ? (
                        <span className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2"></span>
                      ) : null}
                      Save Changes
                   </button>
                </div>
             </form>
           )}
        </div>

      </div>
    </div>
  );
}
