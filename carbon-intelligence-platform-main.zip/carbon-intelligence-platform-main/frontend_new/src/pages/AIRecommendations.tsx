import React, { useState, useEffect } from 'react';
import { BrainCircuit, Sparkles, TrendingDown, DollarSign, Clock, ShieldCheck, Zap, ChevronRight, Info, AlertCircle, RefreshCw, Leaf } from 'lucide-react';
import api from '../services/api';

export default function AIRecommendations() {
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchRecommendations();
  }, []);

  const fetchRecommendations = async () => {
    setRefreshing(true);
    try {
      const res = await api.get('/recommendations/');
      if (res.data.status === 'success') {
        setRecommendations(res.data.recommendations);
      }
    } catch (err) {
      console.error("Failed to load recommendations", err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch(priority.toLowerCase()) {
      case 'high': return 'bg-rose-500 text-white';
      case 'medium': return 'bg-amber-500 text-white';
      case 'low': return 'bg-teal-500 text-white';
      default: return 'bg-slate-500 text-white';
    }
  };

  if (loading) {
     return (
       <div className="min-h-[60vh] flex flex-col items-center justify-center space-y-6">
         <div className="relative">
            <div className="w-24 h-24 rounded-full border-t-2 border-teal-500 animate-spin"></div>
            <BrainCircuit className="w-10 h-10 text-teal-500 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
         </div>
         <p className="text-slate-500 font-black uppercase tracking-[0.3em] text-[10px] animate-pulse italic">Synchronizing with Mistral-7B Intelligence...</p>
       </div>
     );
  }

  return (
    <div className="w-full space-y-10 pb-12 animate-in fade-in slide-in-from-bottom-4 duration-1000">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div>
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight flex items-center gap-4">
            AI <span className="text-gradient">Intelligence Hub</span>
            <Sparkles className="w-6 h-6 text-amber-500 fill-amber-500" />
          </h1>
          <p className="text-slate-500 mt-2 font-medium">Neural strategies mapped from your specific organizational datasets.</p>
        </div>
        <button 
          onClick={fetchRecommendations}
          disabled={refreshing}
          className="flex items-center gap-3 px-8 py-4 bg-slate-900 text-white rounded-2xl font-bold text-sm hover:translate-y-[-2px] transition-all shadow-xl shadow-slate-200 active:scale-95 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          Regenerate Insights
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {recommendations.length > 0 ? (
              recommendations.map((rec, idx) => (
                <div key={rec.id} className="glass-card p-8 rounded-[3rem] border border-slate-200/50 hover:border-teal-500/20 transition-all group overflow-hidden relative">
                  <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-110 transition-transform">
                      <BrainCircuit className="w-24 h-24 text-slate-900" />
                  </div>
                  
                  <div className="flex items-start justify-between mb-8 relative">
                     <div className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest shadow-lg ${getPriorityColor(rec.priority)}`}>
                        {rec.priority} Priority
                     </div>
                     <div className="flex items-center gap-2 text-indigo-600 font-black text-xs uppercase italic">
                       <Clock className="w-3.5 h-3.5" /> ROI {rec.roi}
                     </div>
                  </div>
                  
                  <h3 className="text-2xl font-black text-slate-900 mb-4 tracking-tight leading-tight group-hover:text-teal-600 transition-colors">{rec.strategy}</h3>
                  
                  <div className="space-y-6 pt-6 border-t border-slate-100 relative">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                         <div className="h-10 w-10 rounded-xl bg-teal-500/10 flex items-center justify-center">
                            <TrendingDown className="w-5 h-5 text-teal-600" />
                         </div>
                         <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Reduction Forecast</span>
                      </div>
                      <span className="text-xl font-black text-teal-600">{rec.estimated_reduction}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                         <div className="h-10 w-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
                            <DollarSign className="w-5 h-5 text-blue-600" />
                         </div>
                         <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Implementation Cost</span>
                      </div>
                      <span className="text-xl font-black text-slate-900">{rec.estimated_cost}</span>
                    </div>
                  </div>

                  <button className="w-full mt-10 py-5 bg-slate-50 text-slate-900 rounded-[2rem] font-black uppercase tracking-widest text-[10px] hover:bg-teal-500 hover:text-white transition-all flex items-center justify-center group/btn">
                     Initialize Simulation
                     <ChevronRight className="w-3 h-3 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>
              ))
            ) : (
              <div className="col-span-2 glass-card p-20 rounded-[4rem] flex flex-col items-center text-center">
                 <div className="w-24 h-24 rounded-full bg-slate-50 flex items-center justify-center mb-8 border border-slate-100">
                    <AlertCircle className="w-12 h-12 text-slate-300" />
                 </div>
                 <h3 className="text-2xl font-bold text-slate-900 mb-4">No Neural Mappings Found</h3>
                 <p className="text-slate-500 font-medium max-w-sm">Please initialize your organization dataset to trigger the AI intelligence engine.</p>
              </div>
            )}
          </div>
        </div>

        <div className="lg:col-span-4 space-y-8">
           <div className="p-10 bg-gradient-to-br from-slate-900 to-slate-800 rounded-[3.5rem] text-white shadow-2xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-10 opacity-10 group-hover:scale-110 transition-transform">
                 <Zap className="w-32 h-32 fill-white" />
              </div>
              <h4 className="text-[11px] font-black uppercase tracking-[0.3em] text-teal-400 mb-8 italic">Neural Sentinel Protocol</h4>
              <p className="text-2xl font-bold mb-8 leading-tight">Your sustainability roadmap is tuned to enterprise-grade AI precision.</p>
              
              <div className="space-y-6">
                {[
                  { icon: <ShieldCheck />, label: "Compliance Verified", active: true },
                  { icon: <BrainCircuit />, label: "Mistral-7B Pulse", active: true },
                  { icon: <Leaf />, label: "Direct Impact Vectors", active: true }
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-4">
                     <div className="h-10 w-10 rounded-xl bg-white/10 flex items-center justify-center">
                        {React.cloneElement(item.icon, { className: "w-5 h-5 text-teal-400" })}
                     </div>
                     <span className="text-sm font-bold text-slate-300 tracking-wide">{item.label}</span>
                  </div>
                ))}
              </div>
           </div>

           <div className="glass-card p-10 rounded-[3.5rem] border border-slate-200/50">
              <div className="flex items-center gap-3 mb-8">
                 <Info className="w-5 h-5 text-blue-500" />
                 <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Model Methodology</h4>
              </div>
              <p className="text-sm font-medium text-slate-600 leading-relaxed italic">
                Strategies are synthesized by mapping your historical emission spikes against industry-specific reduction archetypes for the most probable ROI path.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
}
