import React, { useState, useEffect, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, ReferenceLine } from 'recharts';
import { Zap, TrendingDown, DollarSign, Clock, BrainCircuit, Globe, RefreshCw, Info, AlertCircle, ChevronRight, Leaf } from 'lucide-react';
import api from '../services/api';

export default function Simulation() {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    industry: 'Technology',
    production_efficiency_improvement: 10,
    renewable_energy_share: 20,
    reduce_transport_distance: 5
  });

  const [results, setResults] = useState<any>(null);
  const [debounceTimer, setDebounceTimer] = useState<any>(null);

  const runSimulation = useCallback(async (data = formData) => {
    setLoading(true);
    try {
      const res = await api.post('/simulation/run', data);
      setResults(res.data.results);
    } catch (err) {
      console.error("Simulation failure:", err);
    } finally {
      setLoading(false);
    }
  }, [formData]);

  // Initial run
  useEffect(() => {
    runSimulation();
  }, []);

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    const newVal = name === 'industry' ? value : parseFloat(value);
    const updatedForm = { ...formData, [name]: newVal };
    setFormData(updatedForm);

    // Auto-run with debounce for sliders
    if (debounceTimer) clearTimeout(debounceTimer);
    const timer = setTimeout(() => {
      runSimulation(updatedForm);
    }, 800);
    setDebounceTimer(timer);
  };

  const chartData = results ? [
    { name: 'Current', emissions: results.baseline_emissions, color: '#94a3b8' },
    { name: 'Simulated', emissions: results.scenario_emissions, color: '#14b8a6' }
  ] : [];

  return (
    <div className="w-full space-y-8 pb-12 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight flex items-center gap-4">
             Neural <span className="text-gradient">Sandbox</span>
             <div className="px-3 py-1 bg-teal-500/10 text-teal-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-teal-500/20">Reactive Engine</div>
          </h1>
          <p className="text-slate-500 mt-2 font-medium">Calibrate sustainability parameters to visualize real-time emission shifts.</p>
        </div>
        <button 
          onClick={() => runSimulation()}
          className="flex items-center gap-2 px-6 py-3 bg-slate-900 text-white rounded-2xl font-bold text-sm hover:scale-105 transition-all shadow-xl active:scale-95"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          Force Re-Sync
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Control Panel */}
        <div className="lg:col-span-4 space-y-6">
          <div className="glass-card p-8 rounded-[2.5rem] border border-slate-200/50 hover:border-teal-500/20 transition-colors shadow-2xl shadow-slate-200/50">
            <h2 className="text-xl font-bold text-slate-900 mb-8 flex items-center gap-3">
              <Globe className="w-5 h-5 text-teal-500" />
              Intelligence Anchors
            </h2>

            <div className="space-y-10">
              <div className="group">
                <div className="flex justify-between items-center mb-4">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] group-hover:text-teal-600 transition-colors">Renewable Energy Share</label>
                   <span className="text-sm font-black text-teal-600">{formData.renewable_energy_share}%</span>
                </div>
                <input 
                  type="range" name="renewable_energy_share" min="0" max="100" 
                  value={formData.renewable_energy_share} onChange={handleChange}
                  className="w-full h-1.5 bg-slate-100 rounded-full appearance-none cursor-pointer accent-teal-500" 
                />
              </div>

              <div className="group">
                <div className="flex justify-between items-center mb-4">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] group-hover:text-blue-600 transition-colors">Production Efficiency</label>
                   <span className="text-sm font-black text-blue-600">+{formData.production_efficiency_improvement}%</span>
                </div>
                <input 
                  type="range" name="production_efficiency_improvement" min="0" max="50" 
                  value={formData.production_efficiency_improvement} onChange={handleChange}
                  className="w-full h-1.5 bg-slate-100 rounded-full appearance-none cursor-pointer accent-blue-500" 
                />
              </div>

              <div className="group">
                <div className="flex justify-between items-center mb-4">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] group-hover:text-indigo-600 transition-colors">Logistics Optimization</label>
                   <span className="text-sm font-black text-indigo-600">-{formData.reduce_transport_distance}%</span>
                </div>
                <input 
                  type="range" name="reduce_transport_distance" min="0" max="50" 
                  value={formData.reduce_transport_distance} onChange={handleChange}
                  className="w-full h-1.5 bg-slate-100 rounded-full appearance-none cursor-pointer accent-indigo-500" 
                />
              </div>

              <div className="pt-6 border-t border-slate-100">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Industry Sector</label>
                <select 
                  name="industry" value={formData.industry} onChange={handleChange}
                  className="w-full bg-slate-50 border-0 rounded-2xl px-5 py-4 text-slate-900 font-bold outline-none focus:ring-2 focus:ring-teal-500/20 transition-all appearance-none cursor-pointer"
                >
                  {['Technology', 'Manufacturing', 'Energy', 'Transportation', 'Healthcare'].map(i => (
                    <option key={i} value={i}>{i}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="p-6 bg-blue-600 rounded-[2rem] text-white overflow-hidden relative group">
             <div className="absolute top-0 right-0 p-6 opacity-20 group-hover:scale-110 transition-transform">
                <BrainCircuit className="w-12 h-12" />
             </div>
             <p className="text-xs font-black uppercase tracking-widest opacity-60 mb-2">Neural Link Active</p>
             <p className="text-sm font-bold leading-relaxed">System using Mistral-7B to hypothesize additional reduction vectors based on selected parameters.</p>
          </div>
        </div>

        {/* Right: Charts & High Impact Data */}
        <div className="lg:col-span-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="glass-card p-6 rounded-3xl border border-slate-200/50">
               <div className="flex items-center gap-3 text-teal-600 mb-2">
                  <TrendingDown className="w-4 h-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Impact Delta</span>
               </div>
               <p className={`text-3xl font-black ${results?.emission_change.startsWith('-') ? 'text-teal-600' : 'text-slate-900'}`}>
                 {results?.emission_change || '0.0%'}
               </p>
            </div>
            <div className="glass-card p-6 rounded-3xl border border-slate-200/50">
               <div className="flex items-center gap-3 text-blue-600 mb-2">
                  <DollarSign className="w-4 h-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Est. CAPEX</span>
               </div>
               <p className="text-2xl font-black text-slate-900">{results?.cost_impact || '$0'}</p>
            </div>
            <div className="glass-card p-6 rounded-3xl border border-slate-200/50">
               <div className="flex items-center gap-3 text-indigo-600 mb-2">
                  <Clock className="w-4 h-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Return Window</span>
               </div>
               <p className="text-2xl font-black text-slate-900">{results?.roi || '0.0 Yrs'}</p>
            </div>
          </div>

          <div className="glass-card p-8 rounded-[3rem] border border-slate-200/50 h-[400px]">
            <h3 className="text-xl font-bold text-slate-900 mb-8 flex items-center justify-between">
              Emission Profile Comparison
              <div className="flex gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-slate-300"></div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Baseline</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-teal-500"></div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Scenario</span>
                </div>
              </div>
            </h3>
            <div className="h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#64748b', fontWeight: 'bold', fontSize: 12}} 
                  />
                  <YAxis hide />
                  <Tooltip 
                    cursor={{fill: '#f8fafc'}}
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="emissions" radius={[12, 12, 12, 12]} barSize={80}>
                    {chartData.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* AI Insight Console */}
          <div className="glass-card-dark p-10 rounded-[3rem] text-white relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-10">
               <Zap className="w-20 h-20 text-teal-400 opacity-10 group-hover:scale-110 transition-transform" />
            </div>
            
            <div className="flex items-center gap-4 mb-8">
               <div className="h-10 w-10 rounded-xl bg-teal-400/20 flex items-center justify-center">
                  <BrainCircuit className="w-6 h-6 text-teal-400" />
               </div>
               <div>
                  <h3 className="text-2xl font-bold mb-1">Scenario Insights</h3>
                  <p className="text-[10px] font-black text-teal-400 uppercase tracking-[0.3em] italic">AI Logic Stream Active</p>
               </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               {results?.ai_suggestions ? results.ai_suggestions.map((s: any, i: number) => (
                  <div key={i} className="p-6 rounded-[2rem] bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
                     <p className="text-teal-400 text-xs font-black uppercase tracking-widest mb-3 flex items-center gap-2">
                        <Leaf className="w-3.5 h-3.5" /> Strategy Focus {i+1}
                     </p>
                     <p className="text-lg font-bold mb-4">{s.strategy}</p>
                     <div className="flex flex-wrap gap-2">
                        <span className="px-3 py-1 bg-white/10 rounded-full text-[9px] font-bold">Reduction: {s.estimated_reduction}</span>
                        <span className="px-3 py-1 bg-white/10 rounded-full text-[9px] font-bold">Cost: {s.estimated_cost}</span>
                     </div>
                  </div>
               )) : (
                 [1, 2].map(i => (
                    <div key={i} className="h-32 rounded-[2rem] bg-white/5 animate-pulse"></div>
                 ))
               )}
            </div>
            
            <div className="mt-10 pt-8 border-t border-white/5 flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-slate-500">
               <div className="flex items-center gap-4">
                  <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-green-500"></div> Latency: 42ms</span>
                  <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div> Confidence: 94%</span>
               </div>
               <button className="text-teal-400 hover:text-white transition-colors flex items-center gap-2">
                  Full Roadmap <ChevronRight className="w-3 h-3" />
               </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
