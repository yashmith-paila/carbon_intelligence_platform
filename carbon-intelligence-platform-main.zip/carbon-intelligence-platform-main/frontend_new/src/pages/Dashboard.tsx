import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { BarChart3, TrendingDown, Target, Zap, Waves, Shield, Leaf } from 'lucide-react';

export default function Dashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashStats = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        navigate('/signin');
        return;
      }
      try {
        const res = await api.get("/analytics/dashboard-stats");
        setStats(res.data);
      } catch (error) {
        console.error("Error fetching dash stats:", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashStats();
  }, []);

  return (
    <div className="w-full space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">
             Neural <span className="text-gradient">Sustainability</span> Hub
          </h1>
          <p className="text-slate-500 mt-1 font-medium italic">Autonomous Intelligence Engine &copy; 2026</p>
        </div>
        <div className="flex items-center gap-3">
           <div className="px-4 py-2 bg-white rounded-2xl shadow-sm border border-slate-100 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">Live Model: Mistral-7B</span>
           </div>
        </div>
      </div>
      
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1,2,3,4].map(i => (
            <div key={i} className="h-32 rounded-3xl bg-white animate-pulse border border-slate-100 shadow-sm"></div>
          ))}
        </div>
      ) : stats ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="glass-card p-6 rounded-[2rem] relative overflow-hidden group hover:scale-[1.02] transition-transform cursor-pointer">
            <div className="absolute -right-4 -top-4 w-24 h-24 bg-teal-500/10 rounded-full blur-2xl group-hover:bg-teal-500/20 transition-all"></div>
            <div className="flex items-center gap-3 text-teal-600 mb-3">
              <Waves className="w-5 h-5" />
              <span className="text-xs font-black uppercase tracking-widest">Total Footprint</span>
            </div>
            <p className="text-3xl font-black text-slate-900">{stats?.total_emissions || 0} <span className="text-sm font-medium text-slate-400">tCO2e</span></p>
            <div className="mt-4 flex items-center text-xs font-bold text-green-500">
              <TrendingDown className="w-4 h-4 mr-1" />
              <span>5.2% vs last month</span>
            </div>
          </div>
          
          <div className="glass-card p-6 rounded-[2rem] relative overflow-hidden group hover:scale-[1.02] transition-transform cursor-pointer">
             <div className="absolute -right-4 -top-4 w-24 h-24 bg-blue-500/10 rounded-full blur-2xl group-hover:bg-blue-500/20 transition-all"></div>
            <div className="flex items-center gap-3 text-blue-600 mb-3">
              <Zap className="w-5 h-5" />
              <span className="text-xs font-black uppercase tracking-widest">AI Forecast</span>
            </div>
            <p className="text-3xl font-black text-slate-900">{stats?.predicted_emissions || 0} <span className="text-sm font-medium text-slate-400">tCO2e</span></p>
            <p className="mt-4 text-[10px] text-slate-400 font-bold uppercase tracking-tight">Projected for Q3 FY26</p>
          </div>
          
          <div className="glass-card p-6 rounded-[2rem] relative overflow-hidden group hover:scale-[1.02] transition-transform cursor-pointer">
             <div className="absolute -right-4 -top-4 w-24 h-24 bg-indigo-500/10 rounded-full blur-2xl group-hover:bg-indigo-500/20 transition-all"></div>
            <div className="flex items-center gap-3 text-indigo-600 mb-3">
              <BarChart3 className="w-5 h-5" />
              <span className="text-xs font-black uppercase tracking-widest">Data Integrity</span>
            </div>
            <p className="text-3xl font-black text-slate-900">{stats?.record_count || 0} <span className="text-sm font-medium text-slate-400">Signals</span></p>
            <p className="mt-4 text-[10px] text-slate-400 font-bold uppercase tracking-tight">Active Ingestion Active</p>
          </div>
          
          <div className="glass-card p-6 rounded-[2rem] relative overflow-hidden group hover:scale-[1.02] transition-transform cursor-pointer">
             <div className="absolute -right-4 -top-4 w-24 h-24 bg-purple-500/10 rounded-full blur-2xl group-hover:bg-purple-500/20 transition-all"></div>
            <div className="flex items-center gap-3 text-purple-600 mb-3">
              <Target className="w-5 h-5" />
              <span className="text-xs font-black uppercase tracking-widest">Sustainability %</span>
            </div>
            <p className="text-3xl font-black text-slate-900">{stats?.sustainability_progress || 0}%</p>
            <div className="mt-4 w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
               <div className="h-full bg-gradient-to-r from-purple-500 to-indigo-600" style={{width: `${stats?.sustainability_progress || 0}%`}}></div>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-12 glass-card-dark text-white rounded-[2.5rem] text-center">
           <p className="text-xl font-bold mb-2">Neural Link Lost</p>
           <p className="text-slate-400 text-sm">Synchronizing with ML Core...</p>
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-card p-8 rounded-[3rem] relative overflow-hidden">
           <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-slate-900">Neural <span className="text-gradient">Traffic Analysis</span></h2>
              <button className="px-5 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition-colors shadow-lg shadow-slate-900/20">Expand View</button>
           </div>
           
           <div className="h-[400px] w-full rounded-[2rem] bg-slate-100 flex flex-col items-center justify-center relative group overflow-hidden border border-slate-200 shadow-inner">
              <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/20 to-white/40 z-10"></div>
              <div className="relative z-20 flex flex-col items-center gap-4 text-slate-400 group-hover:text-blue-500 transition-colors">
                <Waves className="w-20 h-20 animate-pulse stroke-[1]" />
                <p className="text-sm font-black uppercase tracking-[0.2em]">Neural Network Visualizer Active</p>
              </div>
           </div>
        </div>

        <div className="glass-card-dark p-8 rounded-[3rem] text-white flex flex-col justify-between group overflow-hidden relative">
           <div className="absolute top-0 right-0 p-8">
              <Shield className="w-12 h-12 text-teal-500/10" />
           </div>
           <div>
              <h3 className="text-2xl font-bold mb-2">Organization Health</h3>
              <p className="text-slate-400 text-xs font-black uppercase tracking-widest mb-8">Ecosystem Diagnostics</p>
              
              <div className="space-y-6">
                {[
                  { label: "Data Quality", value: stats?.record_count > 0 ? 98 : 45, color: "bg-teal-500" },
                  { label: "Compliance Index", value: 85, color: "bg-blue-500" },
                  { label: "Energy Optimization", value: 72, color: "bg-indigo-500" }
                ].map((item) => (
                  <div key={item.label}>
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">
                       <span>{item.label}</span>
                       <span className="text-white">{item.value}%</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                       <div className={`h-full ${item.color} rounded-full transition-all duration-1000`} style={{ width: `${item.value}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-8 pt-8 border-t border-white/5">
                 <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.2em] text-teal-400 mb-4 italic">
                    <Leaf className="w-3 h-3" /> Source Classification
                 </div>
                  <div className="flex gap-2">
                     <div className={`flex-1 h-1 rounded-full ${stats?.record_count > 0 ? 'bg-teal-500' : 'bg-slate-800'}`}></div>
                     <div className={`flex-1 h-1 rounded-full ${stats?.record_count === 0 ? 'bg-blue-500' : 'bg-slate-800'}`}></div>
                  </div>
                 <div className="flex justify-between mt-2 text-[8px] font-bold text-slate-500 uppercase tracking-tighter">
                    <span>Automated CSV</span>
                    <span>Manual Audit</span>
                 </div>
              </div>
           </div>
           <p className="mt-8 text-[10px] text-slate-500 font-bold italic leading-relaxed">
             System parameters optimized for {new Date().getFullYear()} ESG frameworks.
           </p>
        </div>
      </div>
    </div>
  );
}
