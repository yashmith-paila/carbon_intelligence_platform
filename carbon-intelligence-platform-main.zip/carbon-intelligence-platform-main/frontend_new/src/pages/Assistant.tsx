import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot, Sparkles, BrainCircuit, ShieldCheck, Zap, Info, Terminal, Maximize2, MoreHorizontal } from 'lucide-react';

export default function Assistant() {
  const [messages, setMessages] = useState([
    { role: 'ai', content: 'Neural link established. I am your AI Sustainability Architect. How shall we optimize your organizational footprint today?' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    const userMsg = input;
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setInput('');
    setIsTyping(true);

    // Mock AI response for demo polish
    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [...prev, { 
        role: 'ai', 
        content: `Analyzing facility clusters... Based on your current trajectory, I recommend shifting 15% more load to the renewable grid during peak production hours. This would improve your ESG score by 4.2 points.` 
      }]);
    }, 1500);
  };

  return (
    <div className="w-full h-full flex flex-col space-y-8 pb-8 animate-in fade-in duration-1000">
      <div className="flex items-center justify-between">
         <div>
            <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight flex items-center gap-4">
               AI <span className="text-gradient">Architect</span>
               <div className="px-3 py-1 bg-indigo-500/10 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-500/20">Secure Instance</div>
            </h1>
            <p className="text-slate-500 mt-2 font-medium">Direct interface with Mistral-7B Neural Network.</p>
         </div>
         <div className="flex gap-4">
            <button className="h-12 w-12 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-400 hover:text-indigo-500 transition-all shadow-sm">
               <Maximize2 className="w-5 h-5" />
            </button>
            <button className="h-12 w-12 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-400 hover:text-indigo-500 transition-all shadow-sm">
               <MoreHorizontal className="w-5 h-5" />
            </button>
         </div>
      </div>

      <div className="flex-1 glass-card rounded-[3rem] border border-slate-200/50 shadow-2xl shadow-slate-200/50 flex flex-col overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-teal-500 via-indigo-500 to-blue-500"></div>
        
        {/* Messages Console */}
        <div ref={scrollRef} className="flex-1 p-10 overflow-y-auto space-y-10 scroll-smooth">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-500`}>
              <div className={`flex gap-6 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`h-12 w-12 rounded-2xl flex items-center justify-center shrink-0 shadow-lg ${msg.role === 'user' ? 'bg-slate-900' : 'bg-gradient-to-br from-teal-400 to-indigo-500'}`}>
                   {msg.role === 'user' ? <User className="w-6 h-6 text-white" /> : <Bot className="w-6 h-6 text-white" />}
                </div>
                <div>
                   <div className={`text-[10px] font-black uppercase tracking-widest mb-2 ${msg.role === 'user' ? 'text-right text-slate-400' : 'text-slate-400'}`}>
                      {msg.role === 'user' ? 'Authorized Manager' : 'Architect Core'}
                   </div>
                   <div className={`rounded-[2rem] px-8 py-5 text-sm font-medium leading-relaxed shadow-sm border ${msg.role === 'user' ? 'bg-slate-900 text-white border-slate-800 rounded-tr-none' : 'bg-white text-slate-800 border-slate-100 rounded-tl-none'}`}>
                      {msg.content}
                   </div>
                </div>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start animate-in fade-in duration-300">
               <div className="flex gap-6 max-w-[85%]">
                  <div className="h-12 w-12 rounded-2xl bg-slate-100 flex items-center justify-center shrink-0">
                     <BrainCircuit className="w-6 h-6 text-slate-400 animate-pulse" />
                  </div>
                  <div className="bg-slate-50 px-8 py-5 rounded-[2rem] rounded-tl-none border border-slate-100 flex gap-2">
                     <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></div>
                     <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-150"></div>
                     <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-300"></div>
                  </div>
               </div>
            </div>
          )}
        </div>

        {/* Input Terminal */}
        <div className="p-8 border-t border-slate-100 bg-slate-50/50 backdrop-blur-sm">
          <form onSubmit={handleSend} className="relative group">
            <div className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-teal-600 transition-colors">
               <Terminal className="w-5 h-5" />
            </div>
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-[2rem] pl-16 pr-32 py-6 text-slate-900 font-bold outline-none focus:ring-4 focus:ring-teal-500/10 focus:border-teal-500/50 transition-all placeholder:text-slate-400"
              placeholder="Query the architect core..."
            />
            <button 
              type="submit" 
              className="absolute right-3 top-1/2 -translate-y-1/2 bg-slate-900 text-white px-8 py-3.5 rounded-[1.5rem] font-black uppercase text-[10px] tracking-widest hover:bg-teal-500 transition-all shadow-xl flex items-center gap-2 group/btn active:scale-95"
            >
              Execute
              <Send className="w-3.5 h-3.5 group-hover/btn:translate-x-1 group-hover/btn:-translate-y-1 transition-transform" />
            </button>
          </form>
          <div className="mt-4 flex items-center justify-center gap-6 text-[9px] font-black uppercase tracking-widest text-slate-400">
             <span className="flex items-center gap-2"><div className="w-1 h-1 bg-green-500 rounded-full"></div> NLP Processor: ACTIVE</span>
             <span className="flex items-center gap-2"><div className="w-1 h-1 bg-indigo-500 rounded-full"></div> Encryption: PGP-2048</span>
          </div>
        </div>
      </div>
    </div>
  );
}
