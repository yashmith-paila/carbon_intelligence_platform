import React from 'react';

export default function DigitalTwin() {
  return (
    <div className="w-full h-[calc(100vh-8rem)]">
      <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-teal-500 to-blue-600 mb-6">
        Digital Twin Visualization
      </h1>
      <div className="bg-gray-900 w-full h-full rounded-2xl shadow-sm overflow-hidden relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <p className="text-gray-500 font-medium">Loading 3D Environment (Three.js)...</p>
        </div>
      </div>
    </div>
  );
}
