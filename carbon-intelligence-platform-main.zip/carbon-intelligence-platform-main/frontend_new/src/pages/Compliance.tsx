import React from 'react';

export default function Compliance() {
  return (
    <div className="w-full">
      <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-teal-500 to-blue-600 mb-6">
        Compliance & Reporting
      </h1>
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
        <p className="text-gray-600 mb-6">Generate sustainability reports compatible with GHG Protocol and ESG standards.</p>
        <div className="flex gap-4">
          <button className="px-6 py-2 bg-teal-600 text-white font-medium rounded-lg hover:bg-teal-700 transition-colors">
            Download PDF Report
          </button>
          <button className="px-6 py-2 bg-white text-teal-600 border border-teal-600 font-medium rounded-lg hover:bg-teal-50 transition-colors">
            Export CSV Data
          </button>
        </div>
      </div>
    </div>
  );
}
