import React, { useState, useEffect } from 'react';
import api from '../services/api';

export default function DatasetUpload() {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [datasets, setDatasets] = useState<any[]>([]);

  useEffect(() => {
    fetchDatasets();
  }, []);

  const fetchDatasets = async () => {
    try {
      const res = await api.get('/emissions/list');
      if (res.data.status === 'success') {
        setDatasets(res.data.emission_records || []);
      }
    } catch (err) {
      console.error("Failed to load datasets", err);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    setLoading(true);
    setMessage('');

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await api.post('/emissions/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      
      if (res.data.status === 'success') {
        setMessage(res.data.message);
        setFile(null);
        const fileInput = document.getElementById('file-upload') as HTMLInputElement;
        if (fileInput) fileInput.value = '';
        fetchDatasets();
      }
    } catch (err: any) {
      setMessage(err.response?.data?.detail || 'Upload failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-teal-500 to-blue-600 mb-2">
        Dataset Management
      </h1>
      <p className="text-gray-500 mb-8">Upload your organization's raw operational data for AI processing.</p>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 border border-gray-100 bg-white p-6 rounded-2xl shadow-sm h-fit">
            <h2 className="text-xl font-semibold mb-4 text-gray-800">Upload Data</h2>
            <form onSubmit={handleUpload}>
                <div className="mb-4">
                    <label 
                        htmlFor="file-upload" 
                        className="flex flex-col items-center justify-center w-full h-48 border-2 border-gray-300 border-dashed rounded-xl cursor-pointer bg-gray-50 hover:bg-gray-100 transition-colors"
                    >
                        <div className="flex flex-col items-center justify-center pt-5 pb-6 text-gray-500">
                            <svg className="w-10 h-10 mb-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path></svg>
                            <p className="mb-2 text-sm"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                            <p className="text-xs">CSV format only</p>
                        </div>
                        <input id="file-upload" type="file" className="hidden" accept=".csv" onChange={handleFileChange} />
                    </label>
                </div>
                {file && (
                    <div className="mb-4 p-3 bg-teal-50 text-teal-700 rounded-lg text-sm border border-teal-100 flex justify-between items-center">
                        <span className="truncate max-w-[200px]">{file.name}</span>
                        <span className="font-medium">{(file.size / 1024).toFixed(1)} KB</span>
                    </div>
                )}
                {message && (
                    <div className={`mb-4 p-3 rounded-lg text-sm ${message.includes('failed') || message.includes('error') ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-green-50 text-green-700 border border-green-100'}`}>
                        {message}
                    </div>
                )}
                <button type="submit" disabled={!file || loading} className="w-full bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium py-2.5 rounded-xl hover:shadow-lg transition-all disabled:opacity-50 flex justify-center items-center">
                  {loading ? <span className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full mr-2"></span> : null}
                  {loading ? 'Processing ML Pipeline...' : 'Upload & Analyze Dataset'}
                </button>
            </form>
        </div>
        <div className="lg:col-span-2 border border-gray-100 bg-white p-6 rounded-2xl shadow-sm">
             <h2 className="text-xl font-semibold mb-4 text-gray-800">Available Datasets</h2>
             {datasets.length === 0 ? (
                 <div className="flex flex-col items-center justify-center p-12 text-center border-2 border-dashed border-gray-100 rounded-xl bg-gray-50">
                    <svg className="w-12 h-12 text-gray-300 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 002-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                    <p className="text-gray-500 font-medium">No datasets found</p>
                    <p className="text-sm text-gray-400 mt-1">Upload an operational dataset to begin ML predictions.</p>
                 </div>
             ) : (
                 <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50 border-b border-gray-100">
                            <tr>
                                <th scope="col" className="px-6 py-3 rounded-tl-lg">Filename</th>
                                <th scope="col" className="px-6 py-3">Rows</th>
                                <th scope="col" className="px-6 py-3">Status</th>
                                <th scope="col" className="px-6 py-3 rounded-tr-lg">Date Added</th>
                            </tr>
                        </thead>
                        <tbody>
                            {datasets.map((ds) => (
                                <tr key={ds.id} className="bg-white border-b border-gray-50 hover:bg-gray-50 transition-colors">
                                    <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap flex items-center">
                                        <svg className="w-4 h-4 mr-2 text-teal-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                        {ds.filename}
                                    </td>
                                    <td className="px-6 py-4">{ds.row_count?.toLocaleString() || '0'}</td>
                                    <td className="px-6 py-4"><span className="bg-green-100 text-green-800 text-xs font-semibold px-2.5 py-0.5 rounded-full border border-green-200">{ds.status}</span></td>
                                    <td className="px-6 py-4 text-gray-400">{new Date(ds.created_at).toLocaleDateString()}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                 </div>
             )}
        </div>
      </div>
    </div>
  );
}
