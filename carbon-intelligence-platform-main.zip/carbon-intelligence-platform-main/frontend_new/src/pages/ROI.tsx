import React from 'react';

export default function ROI() {
  return (
    <div className="w-full">
      <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-teal-500 to-blue-600 mb-6">
        Carbon Cost & ROI
      </h1>
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 mb-6">
        <h2 className="text-xl font-semibold mb-4 text-gray-800">Financial Impact Calculator</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-red-50 p-4 rounded-lg">
            <p className="text-sm text-red-600 font-medium">Carbon Tax Risk</p>
            <p className="text-2xl font-bold text-red-700 mt-1">$45,000</p>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-sm text-green-600 font-medium">Energy Savings</p>
            <p className="text-2xl font-bold text-green-700 mt-1">$120,500</p>
          </div>
          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm text-blue-600 font-medium">Implementation Cost</p>
            <p className="text-2xl font-bold text-blue-700 mt-1">$85,000</p>
          </div>
          <div className="bg-purple-50 p-4 rounded-lg">
            <p className="text-sm text-purple-600 font-medium">ROI Timeline</p>
            <p className="text-2xl font-bold text-purple-700 mt-1">1.8 Years</p>
          </div>
        </div>
      </div>
    </div>
  );
}
