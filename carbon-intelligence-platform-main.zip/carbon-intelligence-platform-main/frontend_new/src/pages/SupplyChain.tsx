import React from 'react';

export default function SupplyChain() {
  return (
    <div className="w-full">
      <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-teal-500 to-blue-600 mb-6">
        Supply Chain Emission Analyzer
      </h1>
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4 text-gray-800">Logistics Overview</h2>
        <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg border border-dashed border-gray-200">
          <p className="text-gray-400">Map and Transport Emissions breakdown will load here</p>
        </div>
      </div>
    </div>
  );
}
