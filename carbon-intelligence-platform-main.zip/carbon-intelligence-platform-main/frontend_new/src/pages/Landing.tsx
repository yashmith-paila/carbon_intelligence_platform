import React, { Suspense } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BarChart3, ShieldCheck, Zap, Globe, Cpu, MousePointer2, Activity, Sparkles, BrainCircuit, Github } from 'lucide-react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Sphere, MeshDistortMaterial, Float } from '@react-three/drei';

function Scene() {
  return (
    <Float speed={2} rotationIntensity={1} floatIntensity={1}>
      <Sphere args={[1, 64, 64]} scale={2.4}>
        <MeshDistortMaterial
          color="#14b8a6"
          attach="material"
          distort={0.4}
          speed={1.5}
          roughness={0}
          emissive="#0d9488"
          emissiveIntensity={0.2}
        />
      </Sphere>
      <gridHelper args={[100, 50, "#334155", "#1e293b"]} rotation={[Math.PI / 2, 0, 0]} position={[0, 0, -5]} />
    </Float>
  );
}

const Landing = () => {
  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans selection:bg-teal-100 selection:text-teal-900 overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-white/40 backdrop-blur-xl border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6 sm:px-10">
          <div className="flex justify-between items-center h-24">
            <div className="flex items-center space-x-3 group cursor-pointer">
              <div className="h-12 w-12 rounded-2xl bg-gradient-to-tr from-teal-400 via-blue-500 to-indigo-600 flex items-center justify-center shadow-2xl shadow-teal-500/20 group-hover:scale-110 transition-transform duration-500">
                <Zap className="text-white w-7 h-7" />
              </div>
              <span className="text-2xl font-black text-slate-900 tracking-tighter">
                Carbon<span className="text-gradient">Sphere</span>
              </span>
            </div>
            <div className="hidden lg:flex items-center space-x-10 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">
              <a href="#features" className="hover:text-teal-600 transition-all hover:tracking-[0.3em]">capabilities</a>
              <a href="#ecosystem" className="hover:text-teal-600 transition-all hover:tracking-[0.3em]">ecosystem</a>
              <Link to="/signin" className="hover:text-teal-600 transition-all hover:tracking-[0.3em]">Access Hub</Link>
              <Link to="/signup" className="px-10 py-4 bg-slate-900 text-white rounded-[1.5rem] hover:bg-teal-600 transition-all shadow-xl hover:-translate-y-1 active:scale-95">
                Join Network
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center pt-24 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full -z-10 bg-white">
           <div className="absolute top-0 right-[-10%] w-[60%] h-full opacity-60">
              <Canvas shadows camera={{ position: [0, 0, 5], fov: 75 }}>
                <ambientLight intensity={0.5} />
                <directionalLight position={[10, 10, 5]} intensity={1} />
                <Suspense fallback={null}>
                  <Scene />
                  <OrbitControls enableZoom={false} />
                </Suspense>
              </Canvas>
           </div>
           <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-teal-400/5 rounded-full blur-[160px]"></div>
           <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-600/5 rounded-full blur-[160px]"></div>
        </div>

        <div className="max-w-7xl mx-auto px-6 sm:px-10 w-full">
          <div className="max-w-3xl relative z-10">
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-slate-50 border border-slate-100 shadow-sm text-teal-600 text-[10px] font-black tracking-[0.2em] uppercase mb-12">
              <Activity className="w-3.5 h-3.5 mr-3 animate-pulse" />
              Empowering Net-Zero Autonomy
              <div className="mx-3 w-1 h-1 bg-slate-300 rounded-full"></div>
              <Sparkles className="w-3 h-3 text-amber-500" />
            </div>
            <h1 className="text-8xl lg:text-[10rem] font-extrabold tracking-tighter text-slate-900 mb-12 leading-[0.8] animate-in fade-in slide-in-from-left-8 duration-1000">
              Future <br />
              <span className="text-gradient">Engineered.</span>
            </h1>
            <p className="max-w-xl text-xl text-slate-500 mb-16 leading-relaxed font-medium animate-in fade-in slide-in-from-left-12 duration-1200delay-200">
              CarbonSphere orchestrates enterprise-wide decarbonization via multi-agent AI networks and spatial data forecasting.
            </p>
            <div className="flex flex-col sm:flex-row items-center gap-6 animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-500">
              <Link to="/signup" className="w-full sm:w-auto px-12 py-6 bg-slate-900 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest hover:bg-teal-500 transition-all shadow-2xl flex items-center justify-center group active:scale-95">
                Initialize Hub
                <MousePointer2 className="ml-3 w-5 h-5 group-hover:rotate-12 transition-transform" />
              </Link>
              <a href="#features" className="w-full sm:w-auto px-12 py-6 bg-white border border-slate-100 text-slate-600 rounded-[2.5rem] font-black text-sm uppercase tracking-widest hover:bg-slate-50 transition-all flex items-center justify-center shadow-lg group">
                Core Protocols
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 bg-white border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-6 sm:px-10">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-12 text-center">
            {[
              { label: "Active Nodes", value: "2,400+" },
              { label: "Data Precision", value: "99.9%" },
              { label: "CO2 Sequestration", value: "1.2M t" },
              { label: "Enterprise ROI", value: "250%" }
            ].map((stat, i) => (
              <div key={i} className="space-y-2">
                <p className="text-4xl font-black text-slate-900 tracking-tighter">{stat.value}</p>
                <p className="text-[10px] font-black uppercase tracking-[.2em] text-slate-400">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-32 relative overflow-hidden bg-slate-900">
        <div className="absolute inset-0 bg-grid-white/[0.02] -z-10"></div>
        <div className="max-w-7xl mx-auto px-6 sm:px-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-24 gap-8">
            <div>
              <h2 className="text-[10px] font-black text-teal-400 tracking-[0.4em] uppercase mb-6">Neural Protocol Engine</h2>
              <h3 className="text-6xl font-black text-white tracking-tighter leading-none">Intelligence Built<br />to Scale.</h3>
            </div>
            <p className="max-w-xs text-slate-500 text-sm font-medium italic">Deploying advanced ML architectures for granular environment monitoring.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {[
              { icon: <Cpu />, title: "Predictive Analytics", desc: "XGBoost and LSTM architectures forecasting emission variances with extreme precision." },
              { icon: <BarChart3 />, title: "Dynamic Reporting", desc: "Automated ESG compliance vectors aligned with global regulatory frameworks." },
              { icon: <ShieldCheck />, title: "Autonomous Guard", desc: "Real-time auditing and anomaly detection across facility sensor networks." },
            ].map((feature, i) => (
              <div key={i} className="bg-white/5 backdrop-blur-xl p-12 rounded-[4rem] border border-white/5 hover:border-teal-500/30 transition-all group hover:bg-white/[0.07] cursor-default">
                <div className="h-16 w-16 rounded-2xl bg-teal-500/10 text-teal-400 flex items-center justify-center mb-10 group-hover:bg-teal-400 group-hover:text-slate-900 transition-all duration-500">
                  {React.cloneElement(feature.icon as React.ReactElement, { className: "w-8 h-8" })}
                </div>
                <h4 className="text-2xl font-bold text-white mb-6 tracking-tight">{feature.title}</h4>
                <p className="text-slate-500 leading-relaxed text-sm font-medium">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AI Simulation CTA */}
      <section id="ecosystem" className="py-32 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 sm:px-10 grid lg:grid-cols-12 gap-20 items-center">
          <div className="lg:col-span-7">
             <div className="glass-card-dark rounded-[4rem] p-16 text-white relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-16 opacity-10 group-hover:scale-110 transition-transform">
                   <BrainCircuit className="w-48 h-48" />
                </div>
                <div className="relative z-10 max-w-lg">
                   <h3 className="text-4xl font-extrabold tracking-tighter mb-8 leading-tight">Test Hypotheses in the <span className="text-teal-400 italic">Neural Sandbox.</span></h3>
                   <p className="text-slate-400 mb-10 font-medium">Calibrate sustainability parameters in real-time to visualize projected ROI and emission delta through our ML forecasting engine.</p>
                   <Link to="/signup" className="inline-flex items-center gap-3 px-10 py-5 bg-teal-500 text-slate-900 rounded-[2rem] font-black uppercase text-xs tracking-widest hover:bg-white transition-all shadow-2xl active:scale-95">
                      Launch Sandbox <ArrowRight className="w-4 h-4" />
                   </Link>
                </div>
             </div>
          </div>
          <div className="lg:col-span-5 space-y-12">
             <div>
                <h4 className="text-xs font-black uppercase tracking-[0.3em] text-teal-600 mb-4 italic">The Ecosystem</h4>
                <h3 className="text-5xl font-black text-slate-900 tracking-tighter leading-none mb-6">Multi-Agent Autonomy.</h3>
                <p className="text-slate-500 font-medium leading-relaxed">Our platform synchronizes multiple AI agents specialized in logistics, energy optimization, and supply chain audit.</p>
             </div>
             <div className="space-y-4">
                {['Real-time sensor integration', 'Mistral-7B recommendation stream', 'Dynamic ESG compliance tracking'].map((item, i) => (
                  <div key={i} className="flex items-center gap-4 text-sm font-black text-slate-900 uppercase tracking-widest">
                     <div className="p-1 rounded-full bg-teal-100 text-teal-600">
                        <Zap className="w-3 h-3 fill-current" />
                     </div>
                     {item}
                  </div>
                ))}
             </div>
          </div>
        </div>
      </section>

      {/* Modern Footer */}
      <footer className="pt-32 pb-20 bg-slate-50/50 border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-6 sm:px-10">
          <div className="grid md:grid-cols-4 gap-16 mb-24">
            <div className="col-span-2 space-y-10">
               <div>
                  <h4 className="text-2xl font-black mb-6">CarbonSphere <span className="text-teal-500">AI</span></h4>
                  <p className="max-w-xs text-slate-500 text-sm font-medium">Global infrastructure for the carbon economic transition. Engineered for autonomy and high-precision decarbonization.</p>
               </div>
               <div className="flex gap-6">
                 <div className="h-10 w-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-400 hover:text-teal-500 cursor-pointer transition-colors shadow-sm"><Github className="w-5 h-5" /></div>
                 <div className="h-10 w-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-400 hover:text-teal-500 cursor-pointer transition-colors shadow-sm"><Globe className="w-5 h-5" /></div>
               </div>
            </div>
            <div>
               <h5 className="text-[10px] font-black uppercase tracking-widest mb-10 text-slate-400">Protocols</h5>
               <ul className="space-y-6 text-sm font-black text-slate-900 uppercase tracking-widest italic">
                 <li className="hover:text-teal-500 cursor-pointer transition-colors">AI Advisory</li>
                 <li className="hover:text-teal-500 cursor-pointer transition-colors">Compliance</li>
                 <li className="hover:text-teal-500 cursor-pointer transition-colors">ROI Predictor</li>
               </ul>
            </div>
            <div>
               <h5 className="text-[10px] font-black uppercase tracking-widest mb-10 text-slate-400">Enterprise</h5>
               <ul className="space-y-6 text-sm font-black text-slate-900 uppercase tracking-widest italic">
                 <li className="hover:text-teal-500 cursor-pointer transition-colors">Security Hub</li>
                 <li className="hover:text-teal-500 cursor-pointer transition-colors">API Integration</li>
                 <li className="hover:text-teal-500 cursor-pointer transition-colors">Global Support</li>
               </ul>
            </div>
          </div>
          <div className="flex flex-col md:flex-row justify-between items-center text-slate-400 text-[10px] font-black uppercase tracking-widest border-t border-slate-200 pt-10">
            <div className="flex items-center gap-4 mb-6 md:mb-0">
              <span>&copy; 2026 Core Logic LLC.</span>
              <div className="w-1.5 h-1.5 bg-slate-200 rounded-full"></div>
              <span className="text-teal-500 animate-pulse">All Clusters Active</span>
            </div>
            <div className="flex space-x-12 italic">
              <a href="#" className="hover:text-teal-600 transition-colors">Privacy</a>
              <a href="#" className="hover:text-teal-600 transition-colors">Terms</a>
              <a href="#" className="hover:text-teal-600 transition-colors">System Nodes</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
