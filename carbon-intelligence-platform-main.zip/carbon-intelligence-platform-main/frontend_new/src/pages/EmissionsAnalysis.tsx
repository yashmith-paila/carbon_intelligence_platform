import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { BarChart, Bar, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Activity, Fingerprint, Shield, Zap, Info, TrendingUp, TrendingDown, Target, LayoutGrid } from 'lucide-react';

export default function EmissionAnalysis() {
  const [correlations, setCorrelations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCorrelations = async () => {
      try {
        const res = await api.get("/analytics/eda");
        if (res.data.status === "success" && res.data.correlations) {
          const formattedData = Object.keys(res.data.correlations).map((key) => ({
            name: key.replace(/_(kWh|Units|kg|km|USD|Percent|Index|Score)/g, '').replace(/_/g, ' '),
            value: Number(res.data.correlations[key])
          })).filter(item => item.value !== 0);
          
          setCorrelations(formattedData);
        }
      } catch (error) {
        console.error("Error fetching correlations:", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchCorrelations();
  }, []);

  return (
    <div className="w-full space-y-10 pb-12 animate-in fade-in duration-1000">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
           <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight flex items-center gap-4">
              Emission <span className="text-gradient">Source Analysis</span>
              <Fingerprint className="w-6 h-6 text-indigo-500" />
           </h1>
           <p className="text-slate-500 mt-2 font-medium">Deep-layer archetypal analysis of emission drivers across your facility infrastructure.</p>
        </div>
        <div className="flex gap-4">
           <div className="px-5 py-3 bg-white border border-slate-200 rounded-2xl flex items-center gap-3">
              <Shield className="w-4 h-4 text-teal-500" />
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-600">Engine: XGBoost</span>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8">
          <div className="glass-card p-10 rounded-[3.5rem] border border-slate-200/50 shadow-2xl shadow-slate-200/40">
            <div className="flex items-center justify-between mb-10">
               <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">Feature Correlation Matrix</h3>
                  <p className="text-xs text-slate-400 font-medium">Correlation strength of specific variables against total carbon footprint.</p>
               </div>
               <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                     <div className="w-2.5 h-2.5 rounded-full bg-rose-500"></div>
                     <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Positive</span>
                  </div>
                  <div className="flex items-center gap-2">
                     <div className="w-2.5 h-2.5 rounded-full bg-teal-500"></div>
                     <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Inverse</span>
                  </div>
               </div>
            </div>

            <div className="h-[500px] w-full">
              {loading ? (
                 <div className="flex h-full flex-col items-center justify-center space-y-4">
                    <div className="w-12 h-12 border-t-2 border-indigo-500 rounded-full animate-spin"></div>
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 animate-pulse italic">Decoding Feature Importance...</p>
                 </div>
              ) : correlations.length > 0 ? (
                 <ResponsiveContainer width="100%" height="100%">
                   <BarChart data={correlations} layout="vertical" margin={{ top: 0, right: 40, left: 120, bottom: 0 }}>
                     <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                     <XAxis type="number" domain={[-1, 1]} hide />
                     <YAxis 
                        dataKey="name" 
                        type="category" 
                        width={120} 
                        axisLine={false}
                        tickLine={false}
                        tick={{fill: '#64748b', fontWeight: 'bold', fontSize: 10}} 
                     />
                     <Tooltip 
                        cursor={{fill: '#f8fafc'}} 
                        contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}} 
                     />
                     <Bar dataKey="value" radius={[0, 10, 10, 0]} barSize={24}>
                       {correlations.map((entry, index) => (
                         <Cell key={`cell-${index}`} fill={entry.value > 0 ? '#f43f5e' : '#14b8a6'} />
                       ))}
                     </Bar>
                   </BarChart>
                 </ResponsiveContainer>
              ) : (
                 <div className="flex h-full flex-col items-center justify-center text-slate-400 opacity-60">
                    <Activity className="w-12 h-12 mb-4" />
                    <p className="font-bold text-sm">Awaiting sufficient data for correlation mapping.</p>
                 </div>
              )}
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-8">
           <div className="glass-card p-10 rounded-[3.5rem] bg-indigo-600 text-white relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-10 opacity-10 group-hover:scale-110 transition-transform">
                 <LayoutGrid className="w-32 h-32" />
              </div>
              <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-200 mb-8 italic">Diagnostic Insights</h3>
              <p className="text-2xl font-bold leading-tight mb-8">Identification of high-variance emission clusters within your production cycle.</p>
              <div className="space-y-6">
                 <div className="p-6 rounded-3xl bg-white/10 hover:bg-white/20 transition-colors cursor-default border border-white/5">
                    <p className="text-[10px] font-black text-indigo-300 uppercase tracking-widest mb-2">Dominant Diver</p>
                    <p className="text-lg font-bold">Energy Intensity (kWh)</p>
                 </div>
                 <div className="p-6 rounded-3xl bg-white/10 hover:bg-white/20 transition-colors cursor-default border border-white/5">
                    <p className="text-[10px] font-black text-indigo-300 uppercase tracking-widest mb-2">Mitigation Vector</p>
                    <p className="text-lg font-bold">Renewable Transition</p>
                 </div>
              </div>
           </div>

           <div className="glass-card p-8 rounded-[3.5rem] border border-slate-200/50">
              <div className="flex items-center gap-3 mb-6">
                 <Info className="w-5 h-5 text-indigo-500" />
                 <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Correlation Logic</h4>
              </div>
              <p className="text-sm font-medium text-slate-500 leading-relaxed">
                Positive correlations (red) indicate factors that increase your carbon footprint. Inverse correlations (teal) represent variables that actively drive emissions lower.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
}
