import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload, FileText, CheckCircle2, AlertCircle, ArrowRight, Database, Keyboard, Leaf } from 'lucide-react';
import api from '../services/api';

export default function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState<'choice' | 'upload' | 'manual'>('choice');
  const [file, setFile] = useState<File | null>(null);
  const [manualData, setManualData] = useState({ scope1: '', scope2: '', scope3: '' });
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setError('');
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    setUploading(true);
    setError('');
    const formData = new FormData();
    formData.append('file', file);
    try {
      await api.post('/organization/upload-dataset', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setSuccess(true);
      window.dispatchEvent(new Event('auth-change'));
      setTimeout(() => navigate('/dashboard'), 2000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to upload dataset.');
    } finally {
      setUploading(false);
    }
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploading(true);
    setError('');
    try {
      await api.post('/organization/manual-onboarding', manualData);
      setSuccess(true);
      window.dispatchEvent(new Event('auth-change'));
      setTimeout(() => navigate('/dashboard'), 2000);
    } catch (err: any) {
      setError('Failed to save data. Please ensure values are numeric.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6 bg-[grid-white/[0.02]]">
      <div className="max-w-2xl w-full">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-teal-500/10 border border-teal-500/20 text-teal-400 text-[10px] font-black uppercase tracking-[0.2em] mb-8">
            <Database className="w-3.5 h-3.5" />
            Node Initialization Required
          </div>
          <h1 className="text-5xl font-black text-white tracking-tighter mb-4">
            Initialize Your <span className="text-gradient">Intelligence Hub.</span>
          </h1>
          <p className="text-slate-400 text-lg font-medium">
            Choose how you want to synchronize your organization's data.
          </p>
        </div>

        <div className="glass-card-dark p-12 rounded-[3.5rem] border border-white/5 relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-teal-500 via-blue-500 to-indigo-600"></div>
          
          {success ? (
            <div className="text-center py-12 animate-in fade-in zoom-in duration-500">
              <div className="w-24 h-24 rounded-full bg-teal-500/10 flex items-center justify-center mx-auto mb-8">
                <CheckCircle2 className="w-12 h-12 text-teal-400" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">Initialization Complete</h2>
              <p className="text-slate-400 mb-8 italic">Routing you to your neural dashboard...</p>
              <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                <div className="h-full bg-teal-500 animate-progress"></div>
              </div>
            </div>
          ) : step === 'choice' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <button 
                onClick={() => setStep('upload')}
                className="p-8 rounded-[2.5rem] bg-white/5 border border-white/10 hover:border-teal-500/50 hover:bg-teal-500/5 transition-all text-left flex flex-col group/btn"
              >
                <Upload className="w-10 h-10 text-teal-400 mb-6 group-hover/btn:scale-110 transition-transform" />
                <h3 className="text-xl font-bold text-white mb-2">CSV Sync</h3>
                <p className="text-slate-500 text-sm leading-relaxed">Bulk import historical records via CSV dataset.</p>
              </button>

              <button 
                onClick={() => setStep('manual')}
                className="p-8 rounded-[2.5rem] bg-white/5 border border-white/10 hover:border-blue-500/50 hover:bg-blue-500/5 transition-all text-left flex flex-col group/btn"
              >
                <Keyboard className="w-10 h-10 text-blue-400 mb-6 group-hover/btn:scale-110 transition-transform" />
                <h3 className="text-xl font-bold text-white mb-2">Manual Audit</h3>
                <p className="text-slate-500 text-sm leading-relaxed">Direct entry of Scope 1, 2, and 3 annual estimates.</p>
              </button>
            </div>
          ) : step === 'upload' ? (
            <div>
              <button onClick={() => setStep('choice')} className="text-slate-500 hover:text-white text-xs font-black uppercase tracking-widest mb-8 flex items-center gap-2">
                <ArrowRight className="w-3 h-3 rotate-180" /> Back to Choice
              </button>
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-3">
                <FileText className="w-5 h-5 text-teal-400" />
                Upload Dataset
              </h3>
              <label className={`block border-2 border-dashed rounded-[2rem] p-12 text-center cursor-pointer transition-all ${file ? 'border-teal-500/50 bg-teal-500/5' : 'border-white/10 hover:border-white/20'}`}>
                <input type="file" accept=".csv" onChange={handleFileChange} className="hidden" />
                <Upload className="w-10 h-10 mx-auto mb-4 text-slate-500" />
                <p className="text-white font-bold">{file ? file.name : 'Choose CSV File'}</p>
              </label>
              <button disabled={!file || uploading} onClick={handleUpload} className="w-full mt-8 py-5 bg-teal-500 text-slate-900 rounded-[2rem] font-black uppercase tracking-widest hover:bg-white transition-all disabled:opacity-50 flex justify-center items-center">
                {uploading ? 'Synchronizing...' : 'Deploy Data'}
              </button>
            </div>
          ) : (
            <div>
              <button onClick={() => setStep('choice')} className="text-slate-500 hover:text-white text-xs font-black uppercase tracking-widest mb-8 flex items-center gap-2">
                <ArrowRight className="w-3 h-3 rotate-180" /> Back to Choice
              </button>
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-3">
                <Leaf className="w-5 h-5 text-blue-400" />
                Emission Scope Audit
              </h3>
              <form onSubmit={handleManualSubmit} className="space-y-6">
                <div>
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Scope 1 (Direct Emissions)</label>
                  <input 
                    type="number" 
                    required 
                    value={manualData.scope1} 
                    onChange={e => setManualData({...manualData, scope1: e.target.value})}
                    placeholder="e.g. 450.5"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:border-blue-500/50 transition-all font-bold placeholder:text-slate-700" 
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Scope 2 (Indirect Energy)</label>
                  <input 
                    type="number" 
                    required 
                    value={manualData.scope2} 
                    onChange={e => setManualData({...manualData, scope2: e.target.value})}
                    placeholder="e.g. 120.2"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:border-blue-500/50 transition-all font-bold placeholder:text-slate-700" 
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Scope 3 (Supply Chain)</label>
                  <input 
                    type="number" 
                    required 
                    value={manualData.scope3} 
                    onChange={e => setManualData({...manualData, scope3: e.target.value})}
                    placeholder="e.g. 1200.0"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:border-blue-500/50 transition-all font-bold placeholder:text-slate-700" 
                  />
                </div>
                <button disabled={uploading} type="submit" className="w-full mt-4 py-5 bg-blue-600 text-white rounded-[2rem] font-black uppercase tracking-widest hover:bg-white hover:text-blue-600 transition-all disabled:opacity-50 flex justify-center items-center group">
                  {uploading ? 'Processing Audit...' : 'Authorize Audit'}
                  {!uploading && <ArrowRight className="ml-3 w-5 h-5 group-hover:translate-x-1 transition-transform" />}
                </button>
              </form>
            </div>
          )}
          
          {error && (
            <div className="mt-8 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-start gap-3 text-red-400 text-sm font-medium">
              <AlertCircle className="w-5 h-5 shrink-0" />
              {error}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
