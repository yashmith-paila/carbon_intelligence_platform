import React, { useState } from 'react';
import { FileText, Download, Target, ChevronRight, Layout, PieChart, Shield, History, Plus, RefreshCw, Zap } from 'lucide-react';
import api from '../services/api';

export default function Reports() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [reportType, setReportType] = useState('EDA');
  const [reportData, setReportData] = useState<any>(null);

  const handleGenerate = async () => {
    setLoading(true);
    setSuccess('');
    try {
      const res = await api.post('/reports/generate', { report_type: reportType });
      if (res.data.status === 'success') {
        setSuccess(`Successfully generated ${reportType} Report.`);
        setReportData(res.data);
      }
    } catch (err) {
      console.error("Failed to generate report", err);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = (format: string) => {
    if (!reportData) return;
    const downloadUrl = `${api.defaults.baseURL}/reports/download/${reportData.report_id}?format=${format}`;
    const token = localStorage.getItem('token');
    
    fetch(downloadUrl, {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(response => response.blob())
    .then(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${reportType}_Report.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    })
    .catch(err => console.error("Download failed", err));
  };

  return (
    <div className="w-full space-y-10 pb-12 animate-in fade-in duration-1000">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div>
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight flex items-center gap-4">
             Executive <span className="text-gradient">Intelligence Reports</span>
             <FileText className="w-6 h-6 text-blue-500" />
          </h1>
          <p className="text-slate-500 mt-2 font-medium">Generate enterprise-grade PDF summaries for board-level ESG compliance.</p>
        </div>
        <button className="flex items-center gap-3 px-8 py-4 bg-white border border-slate-200 text-slate-900 rounded-2xl font-bold text-sm hover:bg-slate-50 transition-all shadow-sm">
           <History className="w-4 h-4 text-slate-400" />
           Report History
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-12">
          <div className="glass-card p-12 rounded-[3.5rem] border border-slate-200/50 shadow-2xl shadow-slate-200/40 relative overflow-hidden group">
             <div className="absolute top-0 right-0 p-12 opacity-5 group-hover:scale-110 transition-transform">
                <Layout className="w-48 h-48" />
             </div>
             
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center relative">
                <div>
                   <h2 className="text-2xl font-black text-slate-900 mb-8 tracking-tighter">Build Intelligence Documentation</h2>
                   
                   {success && (
                     <div className="mb-10 p-6 bg-teal-500 border border-teal-400 rounded-3xl text-white font-bold flex items-center gap-4 animate-in zoom-in duration-500">
                        <Zap className="w-6 h-6 fill-white" />
                        {success}
                     </div>
                   )}

                   <div className="space-y-8">
                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Select Domain Scope</label>
                        <select 
                          value={reportType} 
                          onChange={(e) => { setReportType(e.target.value); setReportData(null); }} 
                          className="w-full bg-slate-50 border-0 rounded-2xl px-6 py-5 text-slate-900 font-bold outline-none focus:ring-4 focus:ring-blue-500/10 transition-all appearance-none cursor-pointer"
                        >
                          <option value="EDA">Exploratory Data Analysis (EDA)</option>
                          <option value="Prediction">ESG Predictions & ML Assessment</option>
                          <option value="Simulation">Simulation & Scenarios Impact</option>
                          <option value="Compliance">Regulatory Compliance Summary</option>
                        </select>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                         {[
                            { label: 'Include AI Insights', icon: <Zap /> },
                            { label: 'Raw Data Logs', icon: <History /> },
                            { label: '3D Visual Exports', icon: <PieChart /> },
                            { label: 'ESG Certification', icon: <Shield /> }
                         ].map((opt, i) => (
                            <div key={i} className="px-5 py-4 bg-slate-50 rounded-2xl flex items-center gap-3 border border-slate-100 group/opt hover:bg-white hover:border-blue-500/30 transition-all cursor-pointer">
                               <div className="text-slate-400 group-hover/opt:text-blue-500 transition-colors">
                                  {React.cloneElement(opt.icon as React.ReactElement, { className: "w-4 h-4" })}
                               </div>
                               <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest whitespace-nowrap">{opt.label}</span>
                            </div>
                         ))}
                      </div>

                      <button 
                        onClick={handleGenerate} 
                        disabled={loading}
                        className="w-full py-6 bg-blue-600 text-white rounded-[2.5rem] font-black uppercase tracking-widest text-xs hover:bg-slate-900 transition-all shadow-2xl flex items-center justify-center group/btn disabled:opacity-50"
                      >
                         {loading ? <RefreshCw className="w-5 h-5 animate-spin" /> : (
                           <>
                             Compile Report <Plus className="ml-3 w-4 h-4 group-hover/btn:rotate-90 transition-transform" />
                           </>
                         )}
                      </button>
                   </div>
                </div>

                <div className="hidden lg:block">
                   {reportData ? (
                      <div className="p-10 bg-slate-900 rounded-[3rem] text-white animate-in slide-in-from-right-8 duration-700">
                         <div className="flex items-center gap-4 mb-8">
                            <div className="h-12 w-12 rounded-2xl bg-blue-500 flex items-center justify-center">
                               <FileText className="w-6 h-6" />
                            </div>
                            <div>
                               <h3 className="text-xl font-bold">{reportType} Instance</h3>
                               <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">ID: {reportData.report_id.slice(0, 8)}</p>
                            </div>
                         </div>
                         
                         <div className="space-y-6 mb-10">
                            <p className="text-sm font-medium text-slate-400 leading-relaxed italic">"Executive summary initialized. All ML features synchronized and validated for regulatory audit."</p>
                            <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                               <div className="h-full bg-blue-500 w-full animate-progress"></div>
                            </div>
                         </div>

                         <div className="grid grid-cols-2 gap-4">
                            <button onClick={() => handleDownload('pdf')} className="py-4 bg-white text-slate-900 rounded-2xl font-black uppercase text-[10px] tracking-widest hover:bg-blue-500 hover:text-white transition-all flex items-center justify-center gap-2">
                               <Download className="w-3.5 h-3.5" /> PDF Hub
                            </button>
                            <button onClick={() => handleDownload('csv')} className="py-4 bg-white/10 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest hover:bg-white/20 transition-all flex items-center justify-center gap-2">
                               <Download className="w-3.5 h-3.5" /> CSV Stream
                            </button>
                         </div>
                      </div>
                   ) : (
                      <div className="p-20 text-center border-2 border-dashed border-slate-100 rounded-[3rem] opacity-40">
                         <FileText className="w-24 h-24 mx-auto mb-6 text-slate-200" />
                         <p className="font-black uppercase tracking-widest text-[10px] text-slate-400">Awaiting Compilation</p>
                      </div>
                   )}
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
