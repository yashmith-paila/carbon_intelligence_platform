import { ReactNode } from 'react';
import Sidebar from './Sidebar';
import { User, Bell, Search } from 'lucide-react';

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar />
      <div className="flex-1 md:ml-64 flex flex-col">
        {/* Premium Header */}
        <header className="h-20 bg-white/50 backdrop-blur-md border-b border-slate-200/50 sticky top-0 z-40 px-8 flex items-center justify-between">
           <div className="flex items-center gap-4 bg-slate-100/50 px-4 py-2 rounded-2xl border border-slate-200/50 w-96 group focus-within:ring-2 focus-within:ring-blue-500/20 transition-all">
              <Search className="w-4 h-4 text-slate-400" />
              <input type="text" placeholder="Search insights, models, or records..." className="bg-transparent border-none outline-none text-sm w-full text-slate-600 placeholder:text-slate-400" />
           </div>

           <div className="flex items-center gap-6">
              <button className="relative p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition-all">
                 <Bell className="w-5 h-5" />
                 <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
              </button>
              <div className="h-10 w-px bg-slate-200"></div>
              <div className="flex items-center gap-3 pl-2 group cursor-pointer">
                 <div className="text-right">
                    <p className="text-sm font-bold text-slate-900 leading-none">AI Admin</p>
                    <p className="text-[10px] font-bold text-teal-600 uppercase tracking-tighter mt-1">Enterprise Tier</p>
                 </div>
                 <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-slate-800 to-slate-900 p-0.5 shadow-lg group-hover:scale-105 transition-transform">
                    <div className="w-full h-full rounded-[9px] bg-slate-800 flex items-center justify-center">
                       <User className="w-5 h-5 text-slate-400" />
                    </div>
                 </div>
              </div>
           </div>
        </header>

        <main className="p-8 max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
