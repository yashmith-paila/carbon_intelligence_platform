import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  BarChart2,
  Lightbulb,
  Cpu,
  FileText,
  Settings,
  LogOut,
  ChevronRight,
  Shield,
  Activity,
  Box,
  Truck
} from 'lucide-react';

export default function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const pathname = location.pathname;
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const checkAuth = () => {
    setIsAuthenticated(!!localStorage.getItem('token'));
  };

  useEffect(() => {
    checkAuth();
    window.addEventListener('auth-change', checkAuth);
    return () => window.removeEventListener('auth-change', checkAuth);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    window.dispatchEvent(new Event('auth-change'));
    navigate('/signin');
  };

  const authenticatedMenuItems = [
    { name: 'Dashboard', path: '/dashboard', icon: <LayoutDashboard /> },
    { name: 'Emissions', path: '/dashboard/emissions', icon: <BarChart2 /> },
    { name: 'AI Advisory', path: '/dashboard/recommendations', icon: <Lightbulb /> },
    { name: 'Simulations', path: '/dashboard/simulation', icon: <Cpu /> },
    { name: 'Reports', path: '/dashboard/reports', icon: <FileText /> },
    { name: 'Supply Chain', path: '/dashboard/supply-chain', icon: <Truck /> },
    { name: 'Compliance', path: '/dashboard/compliance', icon: <Shield /> },
    { name: 'ROI Tracker', path: '/dashboard/roi', icon: <Activity /> },
    { name: 'Settings', path: '/dashboard/settings', icon: <Settings /> },
  ];

  if (!isAuthenticated) return null;

  return (
    <div className="w-64 h-screen bg-slate-900 p-6 flex flex-col fixed top-0 left-0 hidden md:flex z-50 border-r border-white/5">
       <div className="flex items-center gap-3 mb-12 px-2">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-teal-400 to-blue-500 flex items-center justify-center shadow-lg shadow-teal-500/20">
             <Box className="text-white w-6 h-6" />
          </div>
          <h1 className="text-2xl font-black text-white tracking-tighter">
            Carbon<span className="text-teal-400">AI</span>
          </h1>
       </div>

       <div className="flex-1 space-y-2 overflow-y-auto no-scrollbar">
         <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-4 px-2">Core Core Navigation</p>
         {authenticatedMenuItems.map((item) => {
           const isActive = pathname === item.path;
           return (
             <Link
               key={item.name}
               to={item.path}
               className={`flex items-center justify-between px-4 py-3 rounded-2xl text-sm transition-all group ${
                 isActive
                 ? 'bg-gradient-to-r from-blue-600/20 to-transparent text-blue-400'
                 : 'text-slate-400 hover:text-white hover:bg-white/5'
               }`}
             >
               <div className="flex items-center gap-3">
                 <span className={`${isActive ? 'text-blue-400' : 'text-slate-500 group-hover:text-slate-300'}`}>
                   {item.icon && React.cloneElement(item.icon as React.ReactElement, { className: "w-5 h-5" })}
                 </span>
                 <span className="font-semibold">{item.name}</span>
               </div>
               {isActive && <ChevronRight className="w-4 h-4" />}
             </Link>
           );
         })}
       </div>

       <div className="pt-6 border-t border-white/5 space-y-4">
          <div className="bg-white/5 rounded-2xl p-4">
             <div className="flex items-center gap-2 mb-2 text-teal-400">
                <Shield className="w-3 h-3" />
                <span className="text-[10px] font-black uppercase tracking-widest">System Guard</span>
             </div>
             <p className="text-[10px] text-slate-400 leading-relaxed font-bold">Encrypted End-to-End Environment</p>
          </div>

          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-bold text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all group"
          >
            <LogOut className="w-5 h-5 group-hover:rotate-12 transition-transform" />
            Sign Out Engine
          </button>
       </div>
    </div>
  );
}
